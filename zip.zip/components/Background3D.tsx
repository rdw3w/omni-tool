'use client';

import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export function Background3D() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden bg-zinc-50 dark:bg-zinc-950">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 z-[1] mix-blend-overlay"></div>
      
      {/* 3D Animated Orbs */}
      <motion.div
        animate={{
          x: [0, 100, 0, -100, 0],
          y: [0, 50, 100, 50, 0],
          scale: [1, 1.2, 1, 0.8, 1],
          rotate: [0, 90, 180, 270, 360]
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute top-[20%] left-[20%] w-[40vw] h-[40vw] rounded-full bg-blue-500/30 blur-[120px] mix-blend-screen dark:mix-blend-color-dodge"
      />
      
      <motion.div
        animate={{
          x: [0, -150, 0, 150, 0],
          y: [0, -100, 0, 100, 0],
          scale: [1, 1.5, 1, 0.9, 1],
          rotate: [360, 270, 180, 90, 0]
        }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-[20%] right-[10%] w-[35vw] h-[35vw] rounded-full bg-purple-500/30 blur-[120px] mix-blend-screen dark:mix-blend-color-dodge"
      />

       <motion.div
        animate={{
          x: [0, 50, -50, 0],
          y: [0, 150, -150, 0],
          scale: [1, 1.3, 0.8, 1]
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-[40%] left-[50%] w-[25vw] h-[25vw] rounded-full bg-sky-400/20 blur-[100px] mix-blend-screen dark:mix-blend-color-dodge"
      />

      <div className="absolute inset-0 backdrop-blur-[50px]"></div>
    </div>
  );
}
