'use client';

import { useEffect, useState, useRef } from 'react';

type BgTheme = string;

const THEMES = ['universe', 'magical', 'hacker'];

export function DynamicBackground() {
  const [themeIndex, setThemeIndex] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const theme = THEMES[themeIndex];

  // Cycle themes every 20 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setThemeIndex((prev) => (prev + 1) % THEMES.length);
    }, 20000);
    return () => clearInterval(interval);
  }, []);

  // Hacker Matrix Rain Effect
  useEffect(() => {
    if (theme !== 'hacker') return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const fontSize = 16;
    const columns = canvas.width / fontSize;
    const drops: number[] = [];

    for (let x = 0; x < columns; x++) {
      drops[x] = Math.random() * -100; // Start at random heights above screen
    }

    let animationFrameId: number;

    const draw = () => {
      // Semi-transparent black to create trailing effect
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = letters.charAt(Math.floor(Math.random() * letters.length));
        
        // Glowing effect for the leading character
        if (Math.random() > 0.95) {
          ctx.fillStyle = '#fff';
          ctx.shadowBlur = 10;
          ctx.shadowColor = '#fff';
        } else {
          ctx.fillStyle = '#0F0';
          ctx.shadowBlur = 0;
        }

        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme]);

  // Render a specific theme's CSS/HTML
  const renderThemeContent = (t: string) => {
    switch (t) {
      case 'universe':
        return (
          <div className="absolute inset-0 bg-[#050510] overflow-hidden">
            {/* Deep space nebula glow */}
            <div className="absolute top-[-20%] left-[-10%] w-[70vw] h-[70vw] bg-purple-900/20 rounded-full mix-blend-screen filter blur-[120px] animate-pulse" style={{ animationDuration: '10s' }} />
            <div className="absolute bottom-[-20%] right-[-10%] w-[60vw] h-[60vw] bg-blue-900/20 rounded-full mix-blend-screen filter blur-[100px] animate-pulse" style={{ animationDuration: '15s' }} />
            
            {/* Star layers with different speeds and sizes for parallax effect */}
            <div className="absolute inset-0 opacity-80" style={{ backgroundImage: 'radial-gradient(circle at center, #ffffff 1px, transparent 1px)', backgroundSize: '40px 40px', animation: 'moveStars 40s linear infinite' }} />
            <div className="absolute inset-0 opacity-50" style={{ backgroundImage: 'radial-gradient(circle at center, #ffffff 1.5px, transparent 1.5px)', backgroundSize: '90px 90px', animation: 'moveStars 30s linear infinite reverse' }} />
            <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at center, #ffffff 2px, transparent 2px)', backgroundSize: '150px 150px', animation: 'moveStars 20s linear infinite' }} />
          </div>
        );
      case 'magical':
        return (
          <div className="absolute inset-0 bg-[#0a0014] overflow-hidden">
            {/* Animated gradient blobs */}
            <div className="absolute top-[10%] left-[20%] w-[40vw] h-[40vw] bg-purple-600/40 rounded-full mix-blend-screen filter blur-[100px] animate-blob" />
            <div className="absolute top-[20%] right-[10%] w-[35vw] h-[35vw] bg-cyan-500/40 rounded-full mix-blend-screen filter blur-[100px] animate-blob animation-delay-2000" />
            <div className="absolute bottom-[10%] left-[30%] w-[45vw] h-[45vw] bg-pink-600/40 rounded-full mix-blend-screen filter blur-[100px] animate-blob animation-delay-4000" />
            <div className="absolute bottom-[20%] right-[20%] w-[30vw] h-[30vw] bg-amber-500/30 rounded-full mix-blend-screen filter blur-[100px] animate-blob animation-delay-6000" />
            
            {/* Subtle overlay texture */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
          </div>
        );
      case 'hacker':
        return (
          <div className="absolute inset-0 bg-[#000500]">
            <canvas ref={canvasRef} className="w-full h-full opacity-60 mix-blend-screen" />
            {/* Vignette effect to focus center */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#000_100%)] opacity-80" />
          </div>
        );
      default:
        return <div className="absolute inset-0 bg-zinc-950" />;
    }
  };

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-black">
      {THEMES.map((t, idx) => (
        <div 
          key={t}
          className={`absolute inset-0 transition-opacity duration-2000 ease-in-out ${themeIndex === idx ? 'opacity-100' : 'opacity-0'}`}
        >
          {renderThemeContent(t)}
        </div>
      ))}

      <style jsx global>{`
        @keyframes moveStars {
          from { transform: translateY(0) translateX(0); }
          to { transform: translateY(-200px) translateX(-50px); }
        }
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(50px, -50px) scale(1.1); }
          66% { transform: translate(-40px, 40px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob { animation: blob 10s infinite alternate cubic-bezier(0.4, 0, 0.2, 1); }
        .animation-delay-2000 { animation-delay: 2s; }
        .animation-delay-4000 { animation-delay: 4s; }
        .animation-delay-6000 { animation-delay: 6s; }
      `}</style>
    </div>
  );
}
