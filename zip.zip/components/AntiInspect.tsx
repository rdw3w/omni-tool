'use client';

import { useEffect, useState } from 'react';

export function AntiInspect() {
  const [caught, setCaught] = useState(false);

  useEffect(() => {
    // Clear the console and print the polite apology message for devtools users
    console.clear();
    console.log(
      "%cShatarudra\n%cSorry Bhai 🙏", 
      "color: #3b82f6; font-size: 40px; font-weight: 900; text-shadow: 0 0 10px rgba(59, 130, 246, 0.5);", 
      "color: white; font-size: 24px; font-weight: bold; background: #000; padding: 10px; border-radius: 5px;"
    );

    const handleKeyDown = (e: KeyboardEvent) => {
      // F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
      if (
        e.key === 'F12' ||
        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'i' || e.key === 'j' || e.key === 'C' || e.key === 'c')) ||
        (e.ctrlKey && (e.key === 'U' || e.key === 'u'))
      ) {
        e.preventDefault();
        setCaught(true);
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      setCaught(true);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('contextmenu', handleContextMenu);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, []);

  if (caught) {
    return (
      <div className="fixed inset-0 z-[999999] bg-black flex flex-col items-center justify-center space-y-4">
        <h1 className="text-blue-500 text-5xl md:text-8xl font-black uppercase tracking-tighter drop-shadow-[0_0_30px_rgba(59,130,246,0.8)] text-center px-4">
          Shatarudra
        </h1>
        <p className="text-white text-3xl md:text-5xl font-bold tracking-widest animate-pulse">
          Sorry Bhai 🙏
        </p>
      </div>
    );
  }

  return null;
}
