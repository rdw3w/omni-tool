'use client';

import { useEffect } from 'react';

export function UserTracker() {
  useEffect(() => {
    let userId = localStorage.getItem('rudra_user_id');
    if (!userId) {
      userId = 'user_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
      localStorage.setItem('rudra_user_id', userId);
    }
    
    fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    }).catch(console.error);
  }, []);

  return null;
}
