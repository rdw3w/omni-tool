'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

type ToolsState = Record<string, boolean>;

interface AdminContextType {
  tools: ToolsState;
  updateTool: (toolId: string, status: boolean) => Promise<void>;
  isLoading: boolean;
}

const defaultState: ToolsState = {
  chat: true,
  videoGen: true,
  wpGen: true,
  textToSpeech: true,
  aiImage: true,
  aiStory: true,
  aiCode: true,
  aiPrompt: true,
  videoDl: true,
  instaDl: true,
  ytDl: true,
  tiktokDl: true,
  twitterDl: true,
  fbDl: true,
  pinterestDl: true,
  redditDl: true,
  todoList: true,
  notepad: true,
  wordCounter: true,
  loremIpsum: true,
  pomodoro: true,
  markdown: true,
  habitTracker: true,
  expenseTracker: true,
  qr: true,
  passwordGen: true,
  tempMail: true,
  currencyConverter: true,
  unitConverter: true,
  bmiCalculator: true,
  ageCalculator: true,
  stopwatch: true,
  jsonFormatter: true,
  base64: true,
  hashGen: true,
  colorPicker: true,
  imageCompressor: true,
  urlShortener: true,
  jwtDecoder: true,
  cssGradient: true,
  waifuGen: true,
  memeGen: true,
  githubInfo: true,
  tgInfo: true,
};

const AdminContext = createContext<AdminContextType>({
  tools: defaultState,
  updateTool: async () => {},
  isLoading: true,
});

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const [tools, setTools] = useState<ToolsState>(defaultState);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/tools')
      .then(res => res.json())
      .then(data => {
        // Merge fetched data with default state to ensure new tools are included
        setTools({ ...defaultState, ...data });
        setIsLoading(false);
      })
      .catch(err => {
        console.error('Failed to load tools state', err);
        setIsLoading(false);
      });
  }, []);

  const updateTool = async (toolId: string, status: boolean) => {
    const newTools = { ...tools, [toolId]: status };
    setTools(newTools); // Optimistic update
    
    try {
      await fetch('/api/admin/tools', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [toolId]: status }),
      });
    } catch (error) {
      console.error('Failed to update tool state', error);
      // Revert on failure
      setTools(tools);
    }
  };

  return (
    <AdminContext.Provider value={{ tools, updateTool, isLoading }}>
      {children}
    </AdminContext.Provider>
  );
}

export const useAdmin = () => useContext(AdminContext);
