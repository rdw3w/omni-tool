'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTheme } from 'next-themes';
import { useAdmin } from '@/components/AdminProvider';
import { 
  MessageSquare, 
  Image as ImageIcon, 
  Video, 
  Download, 
  Instagram, 
  QrCode,
  Menu,
  X,
  Sun,
  Moon,
  FileText,
  Key,
  Type,
  Mail,
  Shield,
  DollarSign,
  BookOpen,
  Calculator,
  Scale,
  Activity,
  Calendar,
  Code,
  Hash,
  Fingerprint,
  AlignLeft,
  Palette,
  Volume2,
  Timer,
  ListTodo,
  FileEdit,
  ImageMinus,
  Link as LinkIcon,
  Wand2,
  Code2,
  Youtube,
  Music,
  Twitter,
  Facebook,
  MessageCircle,
  CheckSquare,
  Wallet,
  Unlock,
  FileCode2,
  Sparkles
} from 'lucide-react';
import { useState, useEffect } from 'react';

const navItems = [
  { id: 'chat', name: '🤖 AI Chat', href: '/chat', icon: MessageSquare },
  { id: 'videoGen', name: '🎬 AI Video Gen', href: '/video-gen', icon: Video },
  { id: 'wpGen', name: '📝 WP Post Gen', href: '/wp-generator', icon: FileText },
  { id: 'textToSpeech', name: '🗣️ Text to Speech', href: '/text-to-speech', icon: Volume2 },
  { id: 'aiImage', name: '🎨 AI Image Gen', href: '/ai-image', icon: Wand2 },
  { id: 'aiStory', name: '📖 AI Story Gen', href: '/ai-story', icon: BookOpen },
  { id: 'aiCode', name: '💻 AI Code Assist', href: '/ai-code', icon: Code2 },
  { id: 'aiPrompt', name: '✨ AI Prompt Builder', href: '/ai-prompt', icon: Sparkles },

  { id: 'videoDl', name: '⬇️ Universal DL', href: '/video-dl', icon: Download },
  { id: 'instaDl', name: '📸 Insta DL', href: '/insta-dl', icon: Instagram },
  { id: 'ytDl', name: '▶️ YouTube DL', href: '/yt-dl', icon: Youtube },
  { id: 'tiktokDl', name: '🎵 TikTok DL', href: '/tiktok-dl', icon: Music },
  { id: 'twitterDl', name: '🐦 Twitter DL', href: '/twitter-dl', icon: Twitter },
  { id: 'fbDl', name: '📘 Facebook DL', href: '/fb-dl', icon: Facebook },
  { id: 'pinterestDl', name: '📌 Pinterest DL', href: '/pinterest-dl', icon: ImageIcon },
  { id: 'redditDl', name: '🔥 Reddit DL', href: '/reddit-dl', icon: MessageCircle },

  { id: 'todoList', name: '📋 To-Do List', href: '/todo-list', icon: ListTodo },
  { id: 'notepad', name: '📝 Notepad', href: '/notepad', icon: FileEdit },
  { id: 'wordCounter', name: '🔢 Word Counter', href: '/word-counter', icon: Type },
  { id: 'loremIpsum', name: '📃 Lorem Ipsum', href: '/lorem-ipsum', icon: AlignLeft },
  { id: 'pomodoro', name: '🍅 Pomodoro', href: '/pomodoro', icon: Timer },
  { id: 'markdown', name: '👀 Markdown Editor', href: '/markdown', icon: FileCode2 },
  { id: 'habitTracker', name: '✅ Habit Tracker', href: '/habit-tracker', icon: CheckSquare },
  { id: 'expenseTracker', name: '💰 Expense Tracker', href: '/expense-tracker', icon: Wallet },

  { id: 'qr', name: '🔲 QR Generator', href: '/qr', icon: QrCode },
  { id: 'passwordGen', name: '🔑 Password Gen', href: '/password-gen', icon: Key },
  { id: 'tempMail', name: '📧 Temp Mail', href: '/temp-mail', icon: Mail },
  { id: 'currencyConverter', name: '💱 Currency Conv', href: '/currency-converter', icon: DollarSign },
  { id: 'unitConverter', name: '⚖️ Unit Converter', href: '/unit-converter', icon: Scale },
  { id: 'bmiCalculator', name: '⚕️ BMI Calculator', href: '/bmi-calculator', icon: Activity },
  { id: 'ageCalculator', name: '🎂 Age Calculator', href: '/age-calculator', icon: Calendar },
  { id: 'stopwatch', name: '⏱️ Stopwatch', href: '/stopwatch', icon: Timer },

  { id: 'jsonFormatter', name: '>{</> JSON Formatter', href: '/json-formatter', icon: Code },
  { id: 'base64', name: '🏷️ Base64 Encoder', href: '/base64', icon: Hash },
  { id: 'hashGen', name: '🛡️ Hash Generator', href: '/hash-gen', icon: Fingerprint },
  { id: 'colorPicker', name: '🎨 Color Picker', href: '/color-picker', icon: Palette },
  { id: 'imageCompressor', name: '🗜️ Image Compress', href: '/image-compressor', icon: ImageMinus },
  { id: 'urlShortener', name: '🔗 URL Shortener', href: '/url-shortener', icon: LinkIcon },
  { id: 'jwtDecoder', name: '🔓 JWT Decoder', href: '/jwt-decoder', icon: Unlock },
  { id: 'cssGradient', name: '🌈 CSS Gradient', href: '/css-gradient', icon: Palette },
  
  { id: 'waifuGen', name: '🌸 Waifu Gen', href: '/waifu', icon: ImageIcon },
  { id: 'memeGen', name: '😂 Meme Gen', href: '/meme', icon: ImageIcon },
  { id: 'githubInfo', name: '🐙 GitHub Info', href: '/github-info', icon: Hash },
  { id: 'tgInfo', name: '✈️ TG Info', href: '/tg-info', icon: MessageCircle },
];

export function Sidebar() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const { tools } = useAdmin();

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <>
      {/* Mobile menu button */}
      <button 
        className="md:hidden fixed top-4 left-4 z-50 p-2 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white rounded-md shadow-md"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-zinc-950 border-r border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 transition-transform duration-300 ease-in-out flex flex-col
        md:translate-x-0 md:static md:h-screen
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-center h-20 border-b border-zinc-200 dark:border-zinc-800 shrink-0">
          <Link href="/" onClick={() => setIsOpen(false)} className="group">
            <h1 className="text-2xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 drop-shadow-sm group-hover:scale-105 transition-transform" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.2)' }}>
              RUDRA API
            </h1>
            <p className="text-[10px] text-center font-bold tracking-widest text-zinc-400 uppercase mt-1">OmniTools Hub</p>
          </Link>
        </div>
        
        <nav className="p-4 space-y-1 flex-1 overflow-y-auto">
          <div className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2 px-3">Tools</div>
          {navItems.map((item) => {
            if (tools[item.id] === false) return null; // Hide if disabled by admin
            
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setIsOpen(false)}
                className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors
                  ${isActive 
                    ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white font-medium' 
                    : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-white'}
                `}
              >
                <Icon size={20} className={isActive ? 'text-blue-500 dark:text-blue-400' : 'text-zinc-400'} />
                {item.name}
              </Link>
            );
          })}

          <div className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mt-6 mb-2 px-3">Platform</div>
          
          <Link href="/pricing" onClick={() => setIsOpen(false)} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${pathname === '/pricing' ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white font-medium' : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-white'}`}>
            <DollarSign size={20} className={pathname === '/pricing' ? 'text-emerald-500' : 'text-zinc-400'} />
            Pricing
          </Link>
          
          <Link href="/docs" onClick={() => setIsOpen(false)} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${pathname === '/docs' ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white font-medium' : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-white'}`}>
            <BookOpen size={20} className={pathname === '/docs' ? 'text-blue-500' : 'text-zinc-400'} />
            Documentation
          </Link>

          <Link href="/admin" onClick={() => setIsOpen(false)} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors mt-2 ${pathname === '/admin' ? 'bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 font-medium' : 'hover:bg-red-50 dark:hover:bg-red-500/10 text-zinc-600 dark:text-zinc-400 hover:text-red-600 dark:hover:text-red-400'}`}>
            <Shield size={20} />
            Admin Panel
          </Link>
        </nav>

        {/* Theme Toggle & Developer Credit */}
        <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 shrink-0">
          {mounted && (
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="flex items-center gap-3 px-3 py-2.5 w-full rounded-lg transition-colors hover:bg-zinc-50 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-white mb-4"
            >
              {theme === 'dark' ? (
                <>
                  <Sun size={20} className="text-zinc-400" />
                  <span>Light Mode</span>
                </>
              ) : (
                <>
                  <Moon size={20} className="text-zinc-400" />
                  <span>Dark Mode</span>
                </>
              )}
            </button>
          )}

          <div className="text-center bg-zinc-50 dark:bg-zinc-900/50 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800/50">
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Developer</p>
            <p className="text-sm font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500">
              Shatarudra
            </p>
          </div>
        </div>
      </div>

      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
