'use client';

import { useState } from 'react';
import { ImageIcon, Loader2, Download, Sparkles } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function ImageGeneratorPage() {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setImageUrl(null);

    try {
      const res = await fetch(`/api/image?prompt=${encodeURIComponent(prompt)}`);
      
      if (!res.ok) {
        throw new Error('Failed to generate image');
      }

      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const data = await res.json();
        if (data.url) {
          setImageUrl(data.url);
        } else {
          throw new Error('Invalid response format');
        }
      } else {
        // It's a blob
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        setImageUrl(url);
      }
    } catch (err) {
      console.error(err);
      setError('Failed to generate image. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        <header className="mb-8 text-center">
          <div className="w-16 h-16 bg-purple-500/10 text-purple-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <ImageIcon size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-2">AI Image Generator</h1>
          <p className="text-zinc-400">Describe what you want to see, and AI will create it.</p>
        </header>

        <form onSubmit={handleGenerate} className="mb-12">
          <div className="relative flex items-center">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A futuristic city at sunset, cyberpunk style..."
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl pl-4 pr-32 py-4 text-sm focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!prompt.trim() || isLoading}
              className="absolute right-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
              Generate
            </button>
          </div>
          {error && <p className="text-red-400 text-sm mt-3 text-center">{error}</p>}
        </form>

        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden">
          {isLoading ? (
            <div className="flex flex-col items-center text-zinc-400">
              <Loader2 size={48} className="animate-spin mb-4 text-purple-500" />
              <p>Generating your masterpiece...</p>
              <p className="text-xs mt-2 opacity-60">This might take a few seconds.</p>
            </div>
          ) : imageUrl ? (
            <div className="w-full h-full flex flex-col items-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img 
                src={imageUrl} 
                alt={prompt} 
                className="max-w-full max-h-[600px] object-contain rounded-xl shadow-2xl"
              />
              <a 
                href={imageUrl} 
                download={`generated-image-${Date.now()}.png`}
                className="mt-6 px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-medium flex items-center gap-2 transition-colors"
              >
                <Download size={18} />
                Download Image
              </a>
            </div>
          ) : (
            <div className="text-zinc-500 flex flex-col items-center text-center max-w-sm">
              <ImageIcon size={48} className="mb-4 opacity-20" />
              <p>Your generated image will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
