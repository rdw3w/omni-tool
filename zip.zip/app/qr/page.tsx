'use client';

import { useState } from 'react';
import { QrCode, RefreshCw, Link as LinkIcon, Download } from 'lucide-react';

export default function QRGenerator() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [qrUrl, setQrUrl] = useState<string | null>(null);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true);
    
    const apiUrl = `http://tobi-qr-api.vercel.app/qr?p=${encodeURIComponent(url)}&t=${Date.now()}`;
    setQrUrl(apiUrl);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12 relative">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0 relative z-10">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center justify-center shadow-sm">
            <QrCode size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-500">🔲 QR Code Generator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Generate custom QR codes instantly from any link.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl flex flex-col items-center">
          
          <form onSubmit={handleGenerate} className="w-full flex-col flex gap-4 mb-8">
            <div className="relative">
               <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                 <LinkIcon className="text-zinc-400" size={20} />
               </div>
               <input 
                 type="text"
                 value={url}
                 onChange={(e) => setUrl(e.target.value)}
                 placeholder="Enter a website URL..."
                 className="w-full pl-12 pr-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white font-medium text-lg"
               />
            </div>
            
            <button 
              type="submit"
              disabled={loading || !url.trim()}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-3 shadow-lg shadow-emerald-500/25"
            >
              {loading ? <RefreshCw className="animate-spin" /> : <QrCode />}
              {loading ? 'Generating...' : 'Generate New QR'}
            </button>
          </form>

          <div className="relative w-full max-w-sm aspect-square rounded-2xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shadow-inner flex items-center justify-center border-4 border-emerald-100 dark:border-emerald-900/30 group">
            {loading && <div className="absolute inset-0 flex items-center justify-center bg-white/50 dark:bg-black/50 backdrop-blur-sm z-10"><RefreshCw className="animate-spin text-emerald-500" size={40} /></div>}
            
            {!qrUrl ? (
                <div className="text-center p-6 opacity-60">
                  <QrCode size={48} className="mx-auto text-zinc-400 mb-3" />
                  <p className="text-zinc-500 text-sm font-medium">Your QR code will appear here</p>
                </div>
            ) : (
                <>
                    <img 
                    src={qrUrl} 
                    alt="Generated QR" 
                    className="object-contain w-full h-full bg-white p-4"
                    onLoad={() => setLoading(false)}
                    onError={() => setLoading(false)}
                    />
                    <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                    <a href={qrUrl} target="_blank" download="qr-code.png" className="w-12 h-12 bg-zinc-900/90 backdrop-blur-sm shadow-xl rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform">
                        <Download size={20} className="text-emerald-500" />
                    </a>
                    </div>
                </>
            )}
          </div>
        </div>

        <div className="mt-12 text-center pb-8 pt-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
