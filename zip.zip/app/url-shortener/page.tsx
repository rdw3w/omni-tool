'use client';

import { useState } from 'react';
import { Link as LinkIcon, Copy, Check } from 'lucide-react';

export default function UrlShortener() {
  const [url, setUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [copied, setCopied] = useState(false);

  const shortenUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    // Mock URL shortening
    const randomString = Math.random().toString(36).substring(2, 8);
    setShortUrl(`https://rudra.api/${randomString}`);
  };

  const copyToClipboard = () => {
    if (shortUrl) {
      navigator.clipboard.writeText(shortUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-blue-200 dark:bg-blue-500/20 text-blue-700 dark:text-blue-400 rounded-2xl flex items-center justify-center shadow-sm">
            <LinkIcon size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">URL Shortener</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Shorten long URLs for easy sharing.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={shortenUrl} className="mb-8">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Long URL</label>
            <div className="flex gap-4">
              <input
                type="url"
                required
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/very/long/url/that/needs/shortening"
                className="flex-1 px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white text-lg"
              />
              <button 
                type="submit"
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-colors"
              >
                Shorten
              </button>
            </div>
          </form>

          {shortUrl && (
            <div className="p-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-2xl">
              <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400 mb-2">Your short URL</p>
              <div className="flex items-center justify-between bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4">
                <a href={shortUrl} target="_blank" rel="noopener noreferrer" className="text-xl font-bold text-blue-600 dark:text-blue-400 hover:underline truncate mr-4">
                  {shortUrl}
                </a>
                <button 
                  onClick={copyToClipboard}
                  className="flex items-center gap-2 px-4 py-2 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-sm font-medium transition-colors shrink-0"
                >
                  {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
