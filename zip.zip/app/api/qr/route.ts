import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const link = searchParams.get('link');

  if (!link) {
    return NextResponse.json({ error: 'Link is required' }, { status: 400 });
  }

  try {
    const res = await fetch(`http://tobi-qr-api.vercel.app/qr?p=${encodeURIComponent(link)}`);
    
    const contentType = res.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      const data = await res.json();
      return NextResponse.json(data);
    } else {
      const arrayBuffer = await res.arrayBuffer();
      return new NextResponse(arrayBuffer, {
        headers: {
          'Content-Type': contentType || 'image/png',
        },
      });
    }
  } catch (error) {
    console.error('QR API Error:', error);
    return NextResponse.json({ error: 'Failed to generate QR code' }, { status: 500 });
  }
}
