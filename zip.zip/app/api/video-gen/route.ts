import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const prompt = searchParams.get('prompt');
  const model = searchParams.get('model') || 'tobi';

  if (!prompt) {
    return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
  }

  try {
    let apiUrl = '';
    if (model === 'rgen') {
      apiUrl = `https://r-gengpt-api.vercel.app/api/text2video?prompt=${encodeURIComponent(prompt)}`;
    } else {
      apiUrl = `https://tobi-aigen-api.vercel.app/gen?vid=${encodeURIComponent(prompt)}`;
    }

    const res = await fetch(apiUrl);
    
    const contentType = res.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      const data = await res.json();
      return NextResponse.json(data);
    } else {
      const arrayBuffer = await res.arrayBuffer();
      return new NextResponse(arrayBuffer, {
        headers: {
          'Content-Type': contentType || 'video/mp4',
        },
      });
    }
  } catch (error) {
    console.error('Video Gen API Error:', error);
    return NextResponse.json({ error: 'Failed to generate video' }, { status: 500 });
  }
}
