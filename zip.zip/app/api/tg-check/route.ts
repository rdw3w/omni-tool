import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const username = searchParams.get('username');

  if (!username) {
    return NextResponse.json({ error: 'Username is required' }, { status: 400 });
  }

  try {
    const cleanUsername = username.replace('@', '');
    const url = `https://t.me/${cleanUsername}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5'
      }
    });

    if (!response.ok) {
        throw new Error('Failed to fetch from Telegram');
    }

    const html = await response.text();

    // Check if the page is literally the homepage or an invalid page
    if (html.includes('<div class="tgme_page_action">') && html.includes('Send Message')) {
       // Proceed to extract
    } else if (!html.includes('tgme_page_title')) {
       return NextResponse.json({ error: 'User or channel not found or invalid' }, { status: 404 });
    }

    // Better regex for og properties no matter the attribute order
    const getMeta = (property: string) => {
        const regex = new RegExp(`<meta(?:\\s+[^>]*?)?(?:property|name)=["']${property}["'](?:\\s+[^>]*?)?content=["']([^"']*)["']`, 'i');
        const match = html.match(regex);
        if (match) return match[1];

        // Alternative order: content="..." property="..."
        const regexAlt = new RegExp(`<meta(?:\\s+[^>]*?)?content=["']([^"']*)["'](?:\\s+[^>]*?)?(?:property|name)=["']${property}["']`, 'i');
        const matchAlt = html.match(regexAlt);
        if (matchAlt) return matchAlt[1];

        return null;
    };

    const title = getMeta('og:title');
    const description = getMeta('og:description');
    const image = getMeta('og:image');

    // If it's an invalid profile, t.me still returns a 200 page but with generic Telegram title.
    if (!title || title === 'Telegram') {
       return NextResponse.json({
           username: cleanUsername,
           name: `@${cleanUsername}`,
           description: 'Telegram profile is either private, age-restricted, or hidden. You can still open it directly in the app.',
           avatar: null,
           url: url,
           isPrivate: true
       });
    }

    return NextResponse.json({
        username: cleanUsername,
        name: title,
        description: description || 'No description provided.',
        avatar: image || null,
        url: url,
        isPrivate: false
    });

  } catch (error: any) {
    const cleanUsername = username.replace('@', '');
    return NextResponse.json({ 
        username: cleanUsername,
        name: `@${cleanUsername}`,
        description: 'Unable to fetch deep profile info from Telegram (server restricted). Click the link below to view it directly in your App.',
        avatar: null,
        url: `https://t.me/${cleanUsername}`,
        isPrivate: true
    }, { status: 200 }); // Graceful fallback
  }
}
