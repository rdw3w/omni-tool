import { NextResponse } from 'next/server';

// In-memory store for tool statuses
let toolsState: Record<string, boolean> = {
  chat: true,
  image: true,
  videoGen: true,
  videoDl: true,
  instaDl: true,
  qr: true,
  wpGen: true,
  passwordGen: true,
  wordCounter: true,
  tempMail: true,
};

export async function GET() {
  return NextResponse.json(toolsState);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    toolsState = { ...toolsState, ...body };
    return NextResponse.json(toolsState);
  } catch (error) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}
