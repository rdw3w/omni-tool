import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const url = searchParams.get('url');

  if (!url) {
    return NextResponse.json({ error: 'URL is required' }, { status: 400 });
  }

  try {
    const res = await fetch(new URL('/api/universal-dl', request.url), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    
    const data = await res.json();
    if (!res.ok) {
       return NextResponse.json({ error: data.error || 'Failed to fetch Instagram download link' }, { status: res.status });
    }
    return NextResponse.json(data);
  } catch (error: any) {
    console.error('Insta DL API Error:', error);
    return NextResponse.json({ error: error.message || 'Failed to fetch Instagram download link' }, { status: 500 });
  }
}
