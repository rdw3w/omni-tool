import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');
  const email = searchParams.get('email');

  try {
    let url = 'https://r-gengpt-api.vercel.app/api/tamp-mail';
    if (action) {
      url += `?action=${action}`;
      if (email) url += `&email=${email}`;
    }

    const response = await fetch(url);
    const data = await response.text();
    
    try {
      const jsonData = JSON.parse(data);
      return NextResponse.json(jsonData);
    } catch {
      return NextResponse.json({ raw: data });
    }
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch temp mail' }, { status: 500 });
  }
}
