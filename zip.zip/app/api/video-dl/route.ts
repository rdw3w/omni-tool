import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const url = searchParams.get('url');

  if (!url) {
    return NextResponse.json({ error: 'URL is required' }, { status: 400 });
  }

  try {
    const res = await fetch(`https://r-gengpt-api.vercel.app/api/video/download?url=${encodeURIComponent(url)}`);
    
    const contentType = res.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      const data = await res.json();
      return NextResponse.json(data);
    } else {
      const text = await res.text();
      console.error('Video API returned non-JSON:', res.status, text);
      return NextResponse.json({ error: `API returned status ${res.status}` }, { status: res.status === 200 ? 500 : res.status });
    }
  } catch (error) {
    console.error('Video DL API Error:', error);
    return NextResponse.json({ error: 'Failed to fetch video download link' }, { status: 500 });
  }
}
