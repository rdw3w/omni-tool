import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get('url');

  if (!url) {
    return NextResponse.json({ error: 'Twitter URL is required' }, { status: 400 });
  }

  try {
    // Extract username and tweet ID from the URL using Regex
    const match = url.match(/(?:twitter\.com|x\.com)\/(?:#!\/)?(\w+)\/status(es)?\/(\d+)/);
    
    if (!match || match.length < 4) {
      return NextResponse.json({ error: 'Invalid Twitter/X URL' }, { status: 400 });
    }

    const tweetId = match[3];

    // Use vxtwitter (fxTwitter) API for getting JSON data of a tweet
    const apiUrl = `https://api.vxtwitter.com/Twitter/status/${tweetId}`;
    
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0'
      }
    });

    if (!response.ok) {
        throw new Error('Failed to fetch from Twitter API');
    }

    const data = await response.json();

    if (!data.media_extended || data.media_extended.length === 0) {
      return NextResponse.json({
         success: true,
         title: "No Media Found",
         message: "This tweet does not contain any video or image.",
         text: data.text
      });
    }

    // Return the media URLs
    return NextResponse.json({
        success: true,
        title: data.text ? data.text.substring(0, 50) + "..." : "Twitter Media",
        message: "Media fetched successfully!",
        author: data.user_name,
        media: data.media_extended.map((m: any) => ({
            url: m.url,
            type: m.type,
            thumbnail: m.thumbnail_url || m.url
        }))
    });

  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to check Twitter URL' }, { status: 500 });
  }
}
