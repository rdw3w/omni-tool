'use client';

import { useState } from 'react';
import { Hash, Copy, Check } from 'lucide-react';

export default function Base64Encoder() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const processText = () => {
    try {
      if (!input) {
        setOutput('');
        setError('');
        return;
      }
      if (mode === 'encode') {
        setOutput(btoa(input));
      } else {
        setOutput(atob(input));
      }
      setError('');
    } catch (err) {
      setError('Invalid input for decoding');
      setOutput('');
    }
  };

  const copyToClipboard = () => {
    if (output) {
      navigator.clipboard.writeText(output);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-slate-100 dark:bg-slate-500/10 text-slate-600 dark:text-slate-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Hash size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Base64 Encoder/Decoder</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Easily encode or decode Base64 strings.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div className="flex gap-4 mb-6">
            <button
              onClick={() => { setMode('encode'); setOutput(''); setInput(''); setError(''); }}
              className={`flex-1 py-3 rounded-xl font-medium transition-colors ${mode === 'encode' ? 'bg-slate-600 text-white' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700'}`}
            >
              Encode
            </button>
            <button
              onClick={() => { setMode('decode'); setOutput(''); setInput(''); setError(''); }}
              className={`flex-1 py-3 rounded-xl font-medium transition-colors ${mode === 'decode' ? 'bg-slate-600 text-white' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700'}`}
            >
              Decode
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Input Text</label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Enter text to ${mode}...`}
                className="w-full h-32 p-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-500 dark:text-white font-mono text-sm resize-none"
              />
            </div>

            <button 
              onClick={processText}
              className="w-full py-3 bg-slate-600 hover:bg-slate-700 text-white rounded-xl font-medium transition-colors"
            >
              {mode === 'encode' ? 'Encode to Base64' : 'Decode from Base64'}
            </button>

            {error && <p className="text-red-500 text-sm font-medium text-center">{error}</p>}

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Output</label>
                <button 
                  onClick={copyToClipboard}
                  disabled={!output}
                  className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white disabled:opacity-50 transition-colors"
                >
                  {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <textarea
                value={output}
                readOnly
                placeholder="Result will appear here..."
                className="w-full h-32 p-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none dark:text-white font-mono text-sm resize-none"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
