'use client';

import { useState } from 'react';
import { Sparkles, Copy, Check } from 'lucide-react';

export default function AIPromptBuilder() {
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Professional');
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = () => {
    if (!topic) return;
    setResult(`Act as an expert in ${topic}. I need you to provide a comprehensive overview and actionable advice regarding this topic. Please ensure your response is formatted clearly with bullet points where appropriate, and maintain a ${tone.toLowerCase()} tone throughout the explanation.`);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Sparkles size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">AI Prompt Builder</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Craft the perfect prompt for ChatGPT or Claude.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm space-y-6">
          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">What is the topic?</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Digital Marketing, Python Programming"
              className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Tone of Voice</label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
            >
              <option>Professional</option>
              <option>Casual</option>
              <option>Humorous</option>
              <option>Academic</option>
              <option>Creative</option>
            </select>
          </div>

          <button 
            onClick={handleGenerate}
            disabled={!topic}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl font-bold transition-colors"
          >
            Build Prompt
          </button>

          {result && (
            <div className="mt-8 p-6 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl relative">
              <button 
                onClick={copyToClipboard}
                className="absolute top-4 right-4 p-2 bg-white dark:bg-zinc-800 rounded-lg shadow-sm text-zinc-500 hover:text-indigo-600 transition-colors"
              >
                {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
              </button>
              <p className="text-zinc-800 dark:text-zinc-200 pr-10 font-medium">
                {result}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
