'use client';

import { useState } from 'react';
import { Wallet, Plus, Trash2 } from 'lucide-react';

export default function ExpenseTracker() {
  const [expenses, setExpenses] = useState([
    { id: 1, desc: 'Groceries', amount: 45.50 },
    { id: 2, desc: 'Internet Bill', amount: 60.00 },
  ]);
  const [desc, setDesc] = useState('');
  const [amount, setAmount] = useState('');

  const addExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc || !amount) return;
    setExpenses([...expenses, { id: Date.now(), desc, amount: parseFloat(amount) }]);
    setDesc('');
    setAmount('');
  };

  const deleteExpense = (id: number) => {
    setExpenses(expenses.filter(e => e.id !== id));
  };

  const total = expenses.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-500/10 text-green-600 rounded-2xl flex items-center justify-center shadow-sm">
            <Wallet size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Expense Tracker</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Keep track of your daily expenses easily.</p>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="col-span-1 md:col-span-3 bg-green-600 text-white rounded-3xl p-8 shadow-lg flex flex-col items-center justify-center">
            <span className="text-green-200 font-medium mb-2">Total Expenses</span>
            <span className="text-5xl font-black">${total.toFixed(2)}</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={addExpense} className="flex flex-col md:flex-row gap-4 mb-8">
            <input
              type="text"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="Description (e.g., Coffee)"
              className="flex-1 px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 dark:text-white"
            />
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Amount ($)"
              step="0.01"
              min="0"
              className="w-full md:w-48 px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 dark:text-white"
            />
            <button 
              type="submit"
              disabled={!desc || !amount}
              className="px-6 py-3 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white rounded-xl font-bold transition-colors flex items-center justify-center gap-2"
            >
              <Plus size={20} /> Add
            </button>
          </form>

          <div className="space-y-3">
            {expenses.map(expense => (
              <div key={expense.id} className="flex items-center justify-between p-4 border border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50 dark:bg-zinc-950/50">
                <span className="font-medium text-zinc-800 dark:text-zinc-200">{expense.desc}</span>
                <div className="flex items-center gap-4">
                  <span className="font-bold text-zinc-900 dark:text-white">${expense.amount.toFixed(2)}</span>
                  <button 
                    onClick={() => deleteExpense(expense.id)}
                    className="text-zinc-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
            {expenses.length === 0 && (
              <p className="text-center text-zinc-500 py-4">No expenses recorded yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
