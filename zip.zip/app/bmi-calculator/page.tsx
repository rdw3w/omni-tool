'use client';

import { useState } from 'react';
import { Activity } from 'lucide-react';

export default function BMICalculator() {
  const [height, setHeight] = useState('175');
  const [weight, setWeight] = useState('70');

  const calculateBMI = () => {
    const h = parseFloat(height) / 100;
    const w = parseFloat(weight);
    if (h > 0 && w > 0) {
      return (w / (h * h)).toFixed(1);
    }
    return '0.0';
  };

  const getStatus = (bmi: string) => {
    const val = parseFloat(bmi);
    if (val === 0) return { text: '-', color: 'text-zinc-500' };
    if (val < 18.5) return { text: 'Underweight', color: 'text-blue-500' };
    if (val < 25) return { text: 'Normal weight', color: 'text-green-500' };
    if (val < 30) return { text: 'Overweight', color: 'text-orange-500' };
    return { text: 'Obese', color: 'text-red-500' };
  };

  const bmi = calculateBMI();
  const status = getStatus(bmi);

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-2xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Activity size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">BMI Calculator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Calculate your Body Mass Index quickly.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Height (cm)</label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 dark:text-white text-lg"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Weight (kg)</label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 dark:text-white text-lg"
              />
            </div>
          </div>

          <div className="mt-10 p-8 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-center">
            <p className="text-zinc-500 dark:text-zinc-400 text-lg mb-2">Your BMI is</p>
            <p className="text-6xl font-black text-zinc-900 dark:text-white mb-4">{bmi}</p>
            <p className={`text-xl font-bold ${status.color}`}>{status.text}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
