'use client';

import { useState, useEffect, useRef } from 'react';
import { Mail, RefreshCw, Copy, Check, Inbox, Shield, RotateCw, User, Link as LinkIcon, Bot, MailOpen } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

const BASE_URL = 'https://r-gengpt-api.vercel.app/api/tamp-mail';

export default function TempMailPage() {
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [emails, setEmails] = useState<any[]>([]);
  const [activeMailId, setActiveMailId] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [isChecking, setIsChecking] = useState(false);
  const [activeMail, setActiveMail] = useState<any>(null);
  const [isLoadingMail, setIsLoadingMail] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copiedOtp, setCopiedOtp] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    initEmail();
    return () => {
      // Cleanup
    };
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionToken) {
      interval = setInterval(() => {
        fetchInbox(sessionToken);
      }, 15000);
    }
    return () => clearInterval(interval);
  }, [sessionToken]);

  const initEmail = async () => {
    try {
      setIsInitializing(true);
      const response = await fetch(`${BASE_URL}?action=init`);
      const result = await response.json();

      if (result.status === "success") {
        setUserEmail(result.data.email);
        setSessionToken(result.data.token);
        fetchInbox(result.data.token);
      } else {
        alert(result.error?.message || "Error generating email");
      }
    } catch (error) {
      console.error("Init Error:", error);
    } finally {
      setIsInitializing(false);
    }
  };

  const fetchInbox = async (token: string) => {
    try {
      setIsChecking(true);
      const response = await fetch(`${BASE_URL}?action=check&token=${token}`);
      const result = await response.json();

      if (result.status === "success") {
        setEmails(result.data.emails || []);
      }
    } catch (error) {
      console.error("Check Inbox Error:", error);
    } finally {
      setIsChecking(false);
    }
  };

  const readEmail = async (mailId: string) => {
    if (!sessionToken || !mailId) return;
    
    setActiveMailId(mailId);
    setIsLoadingMail(true);
    setActiveMail(null);

    try {
      const response = await fetch(`${BASE_URL}?action=read&token=${sessionToken}&id=${mailId}`);
      const result = await response.json();

      if (result.status === "success") {
        setActiveMail(result.data);
      } else {
        alert("Failed to read email.");
      }
    } catch (error) {
      console.error("Read Error:", error);
    } finally {
      setIsLoadingMail(false);
    }
  };

  useEffect(() => {
    if (activeMail && iframeRef.current) {
      const safeHtml = `
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; padding: 20px; max-width: 100%; word-wrap: break-word; }
            img { max-width: 100%; height: auto; }
            a { color: #2563eb; }
        </style>
        ${activeMail.message_body?.raw_html || activeMail.message_body?.clean_text || ''}
      `;
      iframeRef.current.srcdoc = safeHtml;
    }
  }, [activeMail]);

  const handleCopyEmail = () => {
    if (userEmail) {
      navigator.clipboard.writeText(userEmail);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopyOtp = (otp: string) => {
    navigator.clipboard.writeText(otp);
    setCopiedOtp(true);
    setTimeout(() => setCopiedOtp(false), 2000);
  };

  const extracted = activeMail?.auto_extracted || {};
  const hasOtp = extracted.otp_code && !extracted.otp_code.includes("No OTP");
  const hasLink = extracted.verification_link && !extracted.verification_link.includes("No Verification");

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-slate-100 dark:bg-zinc-950 text-slate-800 dark:text-zinc-200 font-sans transition-colors duration-300">
      
      {/* Navbar */}
      <nav className="bg-white dark:bg-zinc-900 shadow-sm border-b border-slate-200 dark:border-zinc-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <BackButton />
            <div className="flex items-center gap-2">
              <Mail className="text-blue-600 dark:text-blue-500" size={24} />
              <span className="font-bold text-xl tracking-tight text-slate-900 dark:text-white">R-Gen<span className="text-blue-600 dark:text-blue-500">Mail</span></span>
            </div>
          </div>
          <div className="text-sm text-slate-500 dark:text-zinc-400 hidden sm:flex items-center gap-1">
            <Shield className="text-green-500" size={16} /> Enterprise Secured API
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-6">
        
        {/* Hero / Email Address Area */}
        <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm border border-slate-200 dark:border-zinc-800 p-6 md:p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          
          <p className="text-sm font-medium text-slate-500 dark:text-zinc-400 uppercase tracking-wider mb-3">Your Temporary Email Address</p>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-3">
            <div className="relative w-full md:w-auto">
              <input 
                type="text" 
                readOnly 
                value={isInitializing ? "Connecting to API..." : (userEmail || "Failed to generate")} 
                className="w-full md:w-[400px] text-center md:text-left text-lg md:text-2xl font-semibold text-slate-800 dark:text-white bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-700 rounded-xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            </div>
            
            <div className="flex gap-2 w-full md:w-auto justify-center">
              <button 
                onClick={handleCopyEmail} 
                disabled={!userEmail}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-6 py-4 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 w-full md:w-auto shadow-sm"
              >
                {copied ? <Check size={20} /> : <Copy size={20} />} 
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
              <button 
                onClick={initEmail} 
                disabled={isInitializing}
                className="bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300 px-4 py-4 rounded-xl font-medium transition-colors flex items-center justify-center shadow-sm disabled:opacity-50" 
                title="Generate New Email"
              >
                <RefreshCw size={20} className={isInitializing ? "animate-spin" : ""} />
              </button>
            </div>
          </div>
          <p className="text-xs text-slate-400 dark:text-zinc-500 mt-4 flex items-center justify-center gap-1">
            <RotateCw size={12} /> Inbox auto-refreshes every 15 seconds
          </p>
        </div>

        {/* Inbox & Reading Pane Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
          
          {/* Left Pane: Inbox List */}
          <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-sm border border-slate-200 dark:border-zinc-800 flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950 flex justify-between items-center">
              <h2 className="font-semibold text-slate-800 dark:text-white flex items-center">
                <Inbox className="text-blue-600 mr-2" size={18} />
                Inbox 
                <span className="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full ml-2">{emails.length}</span>
              </h2>
              <button 
                onClick={() => sessionToken && fetchInbox(sessionToken)} 
                className="text-slate-400 hover:text-blue-600 transition-colors text-sm" 
                title="Refresh Inbox"
              >
                <RefreshCw size={16} className={isChecking ? "animate-spin" : ""} />
              </button>
            </div>
            <div className="overflow-y-auto flex-grow bg-white dark:bg-zinc-900">
              {isInitializing ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-400">
                  <RefreshCw size={24} className="animate-spin mb-3 text-blue-600" />
                  <p className="text-sm">Connecting to API...</p>
                </div>
              ) : emails.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-400 p-6 text-center">
                  <MailOpen size={32} className="mb-2 text-slate-300 dark:text-zinc-700" />
                  <p className="text-sm">Inbox is empty.<br/>Waiting for incoming emails...</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-zinc-800">
                  {emails.map(mail => {
                    const isActive = mail.id === activeMailId;
                    const timeStr = mail.date.split(' ')[1] || mail.date;
                    return (
                      <div 
                        key={mail.id}
                        onClick={() => readEmail(mail.id)} 
                        className={`p-4 cursor-pointer transition-all border-l-4 ${
                          isActive 
                            ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-600' 
                            : 'hover:bg-slate-50 dark:hover:bg-zinc-800/50 border-transparent'
                        }`}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-semibold text-slate-800 dark:text-zinc-200 text-sm truncate pr-2">{mail.from}</span>
                          <span className="text-xs text-slate-400 whitespace-nowrap">{timeStr}</span>
                        </div>
                        <p className="text-sm text-slate-700 dark:text-zinc-300 font-medium truncate mb-1">{mail.subject || 'No Subject'}</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-500 truncate">{mail.excerpt}...</p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right Pane: Reading Area */}
          <div className="lg:col-span-2 bg-white dark:bg-zinc-900 rounded-2xl shadow-sm border border-slate-200 dark:border-zinc-800 flex flex-col h-full overflow-hidden relative">
            
            {!activeMailId && !isLoadingMail && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-white dark:bg-zinc-900 z-10">
                <div className="w-24 h-24 bg-slate-50 dark:bg-zinc-800 rounded-full flex items-center justify-center mb-4">
                  <MailOpen className="text-4xl text-slate-300 dark:text-zinc-600" size={48} />
                </div>
                <h3 className="text-lg font-medium text-slate-600 dark:text-zinc-400">No email selected</h3>
                <p className="text-slate-400 dark:text-zinc-500 text-sm mt-1">Select an email from the inbox to read it here.</p>
              </div>
            )}

            {isLoadingMail && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-white dark:bg-zinc-900 z-20">
                <RefreshCw size={40} className="animate-spin mb-3 text-blue-600" />
                <p className="text-slate-500 dark:text-zinc-400 font-medium text-sm">Extracting AI Data & Reading...</p>
              </div>
            )}

            {activeMail && !isLoadingMail && (
              <div className="flex flex-col h-full">
                {/* Mail Header */}
                <div className="p-6 border-b border-slate-100 dark:border-zinc-800 bg-white dark:bg-zinc-900">
                  <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-2 line-clamp-2">{activeMail.subject || '(No Subject)'}</h2>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-slate-600 dark:text-zinc-400">
                      <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold">
                        <User size={16} />
                      </div>
                      <span className="font-medium truncate max-w-[200px] md:max-w-md">{activeMail.from}</span>
                    </div>
                    <span className="text-slate-400 whitespace-nowrap">{activeMail.date}</span>
                  </div>
                </div>

                {/* AI Extraction Area (OTP & Links) */}
                {(hasOtp || hasLink) && (
                  <div className="p-4 bg-blue-50/50 dark:bg-blue-900/10 border-b border-blue-100 dark:border-blue-900/30 flex flex-wrap gap-4">
                    {hasOtp && (
                      <div className="bg-white dark:bg-zinc-800 border border-green-200 dark:border-green-900/50 rounded-lg p-3 shadow-sm flex-1 min-w-[200px]">
                        <p className="text-xs text-green-600 dark:text-green-400 font-semibold uppercase mb-1 flex items-center gap-1">
                          <Bot size={14} /> AI Extracted OTP
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold tracking-widest text-slate-800 dark:text-white">{extracted.otp_code}</span>
                          <button onClick={() => handleCopyOtp(extracted.otp_code)} className="text-slate-400 hover:text-green-600 dark:hover:text-green-400">
                            {copiedOtp ? <Check size={20} /> : <Copy size={20} />}
                          </button>
                        </div>
                      </div>
                    )}
                    {hasLink && (
                      <div className="bg-white dark:bg-zinc-800 border border-blue-200 dark:border-blue-900/50 rounded-lg p-3 shadow-sm flex-1 min-w-[200px]">
                        <p className="text-xs text-blue-600 dark:text-blue-400 font-semibold uppercase mb-1 flex items-center gap-1">
                          <LinkIcon size={14} /> Verification Link
                        </p>
                        <a href={extracted.verification_link} target="_blank" rel="noopener noreferrer" className="block w-full text-center bg-blue-600 hover:bg-blue-700 text-white text-sm py-2 rounded transition-colors mt-2 font-medium">
                          Open Link
                        </a>
                      </div>
                    )}
                  </div>
                )}

                {/* Mail Body (Iframe to prevent CSS bleeding) */}
                <div className="flex-grow p-0 bg-white dark:bg-zinc-100 relative">
                  <iframe ref={iframeRef} className="w-full h-full border-none" sandbox="allow-same-origin allow-popups"></iframe>
                </div>
              </div>
            )}
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 border-t border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-center">
        <p className="text-slate-500 dark:text-zinc-400 text-sm">
          Powered by <strong>R-GenGPT Enterprise API</strong> <br/>
          &copy; 2026 Tanjid Islam. All rights reserved.
        </p>
      </footer>
    </div>
  );
}
