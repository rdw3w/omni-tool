'use client';

import { useState, useEffect } from 'react';
import { Type, AlignLeft, Hash, Clock } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function WordCounterPage() {
  const [text, setText] = useState('');
  const [stats, setStats] = useState({
    words: 0,
    characters: 0,
    charactersNoSpaces: 0,
    sentences: 0,
    paragraphs: 0,
    readingTime: 0
  });

  useEffect(() => {
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const characters = text.length;
    const charactersNoSpaces = text.replace(/\s/g, '').length;
    const sentences = text.trim() ? text.split(/[.!?]+/).filter(Boolean).length : 0;
    const paragraphs = text.trim() ? text.split(/\n+/).filter(Boolean).length : 0;
    const readingTime = Math.ceil(words / 200); // 200 words per minute average

    setStats({
      words,
      characters,
      charactersNoSpaces,
      sentences,
      paragraphs,
      readingTime
    });
  }, [text]);

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-white dark:bg-zinc-950 p-6 md:p-12 transition-colors duration-300">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        <header className="mb-8 text-center">
          <div className="w-16 h-16 bg-amber-100 dark:bg-amber-500/10 text-amber-500 dark:text-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Type size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-2 text-zinc-900 dark:text-white">Word Counter</h1>
          <p className="text-zinc-600 dark:text-zinc-400">Count words, characters, sentences, and estimate reading time.</p>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold text-amber-500">{stats.words}</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">Words</span>
          </div>
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold text-blue-500">{stats.characters}</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">Characters</span>
          </div>
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold text-purple-500">{stats.sentences}</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">Sentences</span>
          </div>
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold text-emerald-500">{stats.paragraphs}</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">Paragraphs</span>
          </div>
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold text-rose-500">{stats.charactersNoSpaces}</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">Chars (no spaces)</span>
          </div>
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-bold text-cyan-500">{stats.readingTime}m</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">Reading Time</span>
          </div>
        </div>

        <div className="relative">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type or paste your text here..."
            className="w-full h-96 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-2xl p-6 text-zinc-900 dark:text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all resize-none"
          />
          {text && (
            <button
              onClick={() => setText('')}
              className="absolute top-4 right-4 px-3 py-1 bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-md text-xs font-medium transition-colors"
            >
              Clear Text
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
