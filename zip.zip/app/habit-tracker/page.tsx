'use client';

import { useState } from 'react';
import { CheckSquare, Plus, Trash2 } from 'lucide-react';

export default function HabitTracker() {
  const [habits, setHabits] = useState([
    { id: 1, name: 'Drink Water', streak: 5 },
    { id: 2, name: 'Read 10 Pages', streak: 2 },
    { id: 3, name: 'Exercise', streak: 0 },
  ]);
  const [newHabit, setNewHabit] = useState('');

  const addHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabit.trim()) return;
    setHabits([...habits, { id: Date.now(), name: newHabit, streak: 0 }]);
    setNewHabit('');
  };

  const incrementStreak = (id: number) => {
    setHabits(habits.map(h => h.id === id ? { ...h, streak: h.streak + 1 } : h));
  };

  const deleteHabit = (id: number) => {
    setHabits(habits.filter(h => h.id !== id));
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 rounded-2xl flex items-center justify-center shadow-sm">
            <CheckSquare size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Habit Tracker</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Build good habits and track your daily streaks.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={addHabit} className="flex gap-4 mb-8">
            <input
              type="text"
              value={newHabit}
              onChange={(e) => setNewHabit(e.target.value)}
              placeholder="Enter a new habit..."
              className="flex-1 px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white"
            />
            <button 
              type="submit"
              disabled={!newHabit.trim()}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl font-bold transition-colors flex items-center gap-2"
            >
              <Plus size={20} /> Add
            </button>
          </form>

          <div className="space-y-4">
            {habits.map(habit => (
              <div key={habit.id} className="flex items-center justify-between p-4 border border-zinc-200 dark:border-zinc-800 rounded-2xl bg-zinc-50 dark:bg-zinc-950/50">
                <div>
                  <h3 className="font-bold text-zinc-900 dark:text-white text-lg">{habit.name}</h3>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">Current Streak: <span className="font-bold text-emerald-600 dark:text-emerald-400">{habit.streak} days</span></p>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => incrementStreak(habit.id)}
                    className="px-4 py-2 bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400 rounded-lg font-bold hover:bg-emerald-200 dark:hover:bg-emerald-500/30 transition-colors"
                  >
                    +1 Day
                  </button>
                  <button 
                    onClick={() => deleteHabit(habit.id)}
                    className="p-2 text-zinc-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>
            ))}
            {habits.length === 0 && (
              <p className="text-center text-zinc-500 py-8">No habits added yet. Start building good habits today!</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
