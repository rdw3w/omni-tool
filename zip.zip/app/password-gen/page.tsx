'use client';

import { useState, useEffect } from 'react';
import { Key, Copy, Check, RefreshCw } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function PasswordGeneratorPage() {
  const [password, setPassword] = useState('');
  const [length, setLength] = useState(16);
  const [includeUppercase, setIncludeUppercase] = useState(true);
  const [includeLowercase, setIncludeLowercase] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    let charset = '';
    if (includeLowercase) charset += 'abcdefghijklmnopqrstuvwxyz';
    if (includeUppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeNumbers) charset += '0123456789';
    if (includeSymbols) charset += '!@#$%^&*()_+~`|}{[]:;?><,./-=';

    if (charset === '') {
      setPassword('Please select at least one option');
      return;
    }

    let newPassword = '';
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      newPassword += charset[randomIndex];
    }
    setPassword(newPassword);
    setCopied(false);
  };

  useEffect(() => {
    generatePassword();
  }, [length, includeUppercase, includeLowercase, includeNumbers, includeSymbols]);

  const handleCopy = () => {
    if (password && password !== 'Please select at least one option') {
      navigator.clipboard.writeText(password);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const calculateStrength = () => {
    if (!password || password === 'Please select at least one option') return 0;
    let strength = 0;
    if (password.length >= 12) strength += 1;
    if (password.length >= 16) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    return Math.min(strength, 5);
  };

  const strength = calculateStrength();
  const strengthLabels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
  const strengthColors = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-blue-500', 'bg-emerald-500', 'bg-emerald-600'];

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-white dark:bg-zinc-950 p-6 md:p-12 transition-colors duration-300">
      <div className="max-w-2xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        <header className="mb-8 text-center">
          <div className="w-16 h-16 bg-rose-100 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Key size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-2 text-zinc-900 dark:text-white">Password Generator</h1>
          <p className="text-zinc-600 dark:text-zinc-400">Create strong, secure passwords instantly.</p>
        </header>

        <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 md:p-8">
          
          {/* Password Display */}
          <div className="relative mb-8">
            <div className="w-full bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 pr-24 text-xl md:text-2xl font-mono text-zinc-900 dark:text-white break-all min-h-[60px] flex items-center">
              {password}
            </div>
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-2">
              <button
                onClick={generatePassword}
                className="p-2 text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white transition-colors"
                title="Regenerate"
              >
                <RefreshCw size={20} />
              </button>
              <button
                onClick={handleCopy}
                className="p-2 text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white transition-colors"
                title="Copy"
              >
                {copied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
              </button>
            </div>
          </div>

          {/* Strength Meter */}
          <div className="mb-8">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-zinc-600 dark:text-zinc-400">Password Strength</span>
              <span className="font-medium text-zinc-900 dark:text-white">{strengthLabels[strength]}</span>
            </div>
            <div className="flex gap-1 h-2">
              {[1, 2, 3, 4, 5].map((level) => (
                <div 
                  key={level} 
                  className={`flex-1 rounded-full ${level <= strength ? strengthColors[strength] : 'bg-zinc-200 dark:bg-zinc-800'}`}
                />
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-4">
                <span className="text-zinc-600 dark:text-zinc-400">Password Length</span>
                <span className="font-medium text-zinc-900 dark:text-white">{length}</span>
              </div>
              <input 
                type="range" 
                min="8" 
                max="64" 
                value={length} 
                onChange={(e) => setLength(parseInt(e.target.value))}
                className="w-full accent-rose-500"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={includeUppercase} 
                  onChange={(e) => setIncludeUppercase(e.target.checked)}
                  className="w-5 h-5 rounded border-zinc-300 text-rose-500 focus:ring-rose-500 accent-rose-500"
                />
                <span className="text-zinc-700 dark:text-zinc-300">Uppercase (A-Z)</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={includeLowercase} 
                  onChange={(e) => setIncludeLowercase(e.target.checked)}
                  className="w-5 h-5 rounded border-zinc-300 text-rose-500 focus:ring-rose-500 accent-rose-500"
                />
                <span className="text-zinc-700 dark:text-zinc-300">Lowercase (a-z)</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={includeNumbers} 
                  onChange={(e) => setIncludeNumbers(e.target.checked)}
                  className="w-5 h-5 rounded border-zinc-300 text-rose-500 focus:ring-rose-500 accent-rose-500"
                />
                <span className="text-zinc-700 dark:text-zinc-300">Numbers (0-9)</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={includeSymbols} 
                  onChange={(e) => setIncludeSymbols(e.target.checked)}
                  className="w-5 h-5 rounded border-zinc-300 text-rose-500 focus:ring-rose-500 accent-rose-500"
                />
                <span className="text-zinc-700 dark:text-zinc-300">Symbols (!@#$...)</span>
              </label>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}
