'use client';

import { useState } from 'react';
import { Volume2, RefreshCw, AudioLines } from 'lucide-react';

export default function TextToSpeech() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text) return;
    setLoading(true);
    
    // Direct API usage to fetch TTS Audio
    const apiUrl = `https://tobi-tts-api.vercel.app/api/eng?text=${encodeURIComponent(text)}&t=${Date.now()}`;
    setAudioUrl(apiUrl);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-sky-100 dark:bg-sky-500/10 text-sky-500 rounded-2xl flex items-center justify-center shadow-sm">
            <Volume2 size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-600">🗣️ Text to Speech</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Turn words into lifelike audio instantly.</p>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl">
            <h2 className="text-xl font-bold mb-6 text-zinc-900 dark:text-white flex items-center gap-2">
              <AudioLines className="text-sky-500" /> Enter Text
            </h2>
            <form onSubmit={handleGenerate} className="flex flex-col gap-6">
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Hello World! I am speaking!"
                className="w-full h-40 px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 dark:text-white transition-all text-sm leading-relaxed resize-none"
                required
              />
              <button 
                type="submit"
                disabled={loading || !text}
                className="w-full py-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
              >
                {loading ? <RefreshCw className="animate-spin" /> : <Volume2 />}
                {loading ? 'Synthesizing...' : 'Generate Voice'}
              </button>
            </form>
          </div>

          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl flex flex-col">
            <h2 className="text-xl font-bold mb-6 text-zinc-900 dark:text-white flex items-center gap-2">
              <Volume2 className="text-sky-500" /> Audio Player
            </h2>
            <div className="flex-1 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl flex items-center justify-center relative shadow-inner p-6">
              {!audioUrl ? (
                <div className="text-center p-6 opacity-60">
                  <Volume2 size={48} className="mx-auto text-zinc-400 mb-3" />
                  <p className="text-zinc-500 text-sm font-medium">Your generated audio will play here</p>
                </div>
              ) : (
                <div className="w-full flex justify-center">
                  <audio 
                    src={audioUrl} 
                    controls
                    autoPlay
                    onCanPlay={() => setLoading(false)}
                    onError={() => setLoading(false)}
                    className="w-full max-w-sm rounded-full shadow-lg"
                  />
                  {loading && (
                    <div className="absolute inset-0 z-10 bg-white/60 dark:bg-black/60 backdrop-blur-md flex flex-col items-center justify-center rounded-2xl">
                      <RefreshCw size={40} className="animate-spin text-sky-500 mb-4" />
                      <p className="font-bold text-zinc-800 dark:text-zinc-200 animate-pulse">Encoding Audio...</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-16 text-center pb-8 border-t border-zinc-200 dark:border-zinc-800 pt-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
