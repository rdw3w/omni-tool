'use client';

import { useState } from 'react';
import { FileText, Loader2, Sparkles, Copy, Check } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function WPGeneratorPage() {
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setResult(null);
    setCopied(false);

    try {
      const prompt = `Write a professional, SEO optimized blog post about "${topic}" including H1, H2 tags and a conclusion. Format the response strictly in HTML so it can be pasted directly into WordPress. Do not include markdown code blocks like \`\`\`html.`;
      const res = await fetch(`/api/chat?prompt=${encodeURIComponent(prompt)}`);
      const data = await res.json();
      
      let aiResponse = "Failed to generate content.";
      if (typeof data === 'string') aiResponse = data;
      else if (data.response) aiResponse = data.response;
      else if (data.reply) aiResponse = data.reply;
      else if (data.message) aiResponse = data.message;
      else if (data.text) aiResponse = data.text;

      // Clean up potential markdown blocks if the AI still included them
      aiResponse = aiResponse.replace(/```html/g, '').replace(/```/g, '').trim();
      setResult(aiResponse);
    } catch (err) {
      console.error(err);
      setError('Failed to generate blog post. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (result) {
      navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-white dark:bg-zinc-950 p-6 md:p-12 transition-colors duration-300">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        <header className="mb-8 text-center">
          <div className="w-16 h-16 bg-cyan-100 dark:bg-cyan-500/10 text-cyan-500 dark:text-cyan-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <FileText size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-2 text-zinc-900 dark:text-white">WordPress Post Generator</h1>
          <p className="text-zinc-600 dark:text-zinc-400">Generate SEO-optimized HTML blog posts ready to paste into WordPress.</p>
        </header>

        <form onSubmit={handleGenerate} className="mb-12">
          <div className="relative flex items-center">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter a topic (e.g., Top 10 Benefits of Yoga)..."
              className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl pl-4 pr-32 py-4 text-sm focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all text-zinc-900 dark:text-white"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!topic.trim() || isLoading}
              className="absolute right-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
              Generate
            </button>
          </div>
          {error && <p className="text-red-500 dark:text-red-400 text-sm mt-3 text-center">{error}</p>}
        </form>

        <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 min-h-[400px] flex flex-col relative overflow-hidden">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-full text-zinc-500 dark:text-zinc-400 flex-1 min-h-[300px]">
              <Loader2 size={48} className="animate-spin mb-4 text-cyan-500" />
              <p>Writing your blog post...</p>
              <p className="text-xs mt-2 opacity-60">This might take a few seconds.</p>
            </div>
          ) : result ? (
            <div className="flex flex-col h-full">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-zinc-900 dark:text-white">Generated HTML</h3>
                <button 
                  onClick={handleCopy}
                  className="flex items-center gap-2 px-3 py-1.5 bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-md text-sm transition-colors"
                >
                  {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  {copied ? 'Copied!' : 'Copy HTML'}
                </button>
              </div>
              <div className="bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 overflow-auto flex-1 max-h-[500px]">
                <pre className="text-sm text-zinc-800 dark:text-zinc-300 whitespace-pre-wrap font-mono">
                  {result}
                </pre>
              </div>
            </div>
          ) : (
            <div className="text-zinc-400 dark:text-zinc-500 flex flex-col items-center justify-center text-center flex-1 min-h-[300px]">
              <FileText size={48} className="mb-4 opacity-20" />
              <p>Your generated blog post will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
