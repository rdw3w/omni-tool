'use client';

import { useState } from 'react';
import { Download, Image as ImageIcon, Link as LinkIcon, RefreshCw, Info } from 'lucide-react';

export default function PinterestDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true);
    setResult(null);
    
    try {
      const apiUrl = `/api/universal-dl`;
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to download media");
      setResult(data);
    } catch (e: any) {
      console.error(e);
      setResult({ error: e.message || "Failed to download media" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12 relative">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0 relative z-10">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-500/10 text-red-500 rounded-2xl flex items-center justify-center shadow-sm">
            <ImageIcon size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-rose-600">📌 Pinterest Downloader</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Download any image or video directly from Pinterest.</p>
          </div>
        </header>

        <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Info className="text-red-500 shrink-0 mt-1" size={20} />
          <div className="text-sm text-red-700 dark:text-red-200">
            <p className="font-bold mb-1">Tool Features & Limitations:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Directly downloads High-Resolution images and videos from Pins.</li>
              <li>Includes support for Idea Pins and Video Pins.</li>
              <li>Does not support bulk downloading of entire boards.</li>
            </ul>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl">
          <form onSubmit={handleDownload} className="flex flex-col gap-4 mb-8">
            <div className="relative">
               <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                 <LinkIcon className="text-zinc-400" size={20} />
               </div>
               <input 
                 type="url"
                 value={url}
                 onChange={(e) => setUrl(e.target.value)}
                 placeholder="Paste Pinterest URL (e.g. https://pin.it/...)"
                 className="w-full pl-12 pr-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 dark:text-white font-medium text-lg"
                 required
               />
            </div>
            <button 
              type="submit"
              disabled={loading || !url}
              className="w-full py-4 bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-red-500/25"
            >
              {loading ? <RefreshCw className="animate-spin" /> : <Download />}
              {loading ? 'Processing Link...' : 'Fetch Media'}
            </button>
          </form>

          {result && (
            <div className="mt-8 border-t border-zinc-200 dark:border-zinc-800 pt-8 flex flex-col items-center">
              {result.error ? (
                 <p className="text-red-500 font-bold">{result.error}</p>
              ) : (
                <div className="w-full flex flex-col items-center gap-6">
                  {result.url && (
                    <div className="w-full max-w-sm rounded-2xl overflow-hidden shadow-inner border-4 border-red-50 dark:border-red-900/20 bg-zinc-100 dark:bg-zinc-800">
                       <img src={result.url} alt="Pinterest Media" className="w-full h-auto object-cover" />
                    </div>
                  )}
                  <a href={result.url || '#'} target="_blank" rel="noreferrer" className="w-full max-w-sm py-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-900 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg">
                    <Download size={20} /> Download Media
                  </a>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-12 text-center pb-8 pt-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
