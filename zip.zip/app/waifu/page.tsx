'use client';

import { useState } from 'react';
import { Heart, RefreshCw } from 'lucide-react';

export default function WaifuGenerator() {
  const [imageUrl, setImageUrl] = useState('https://waifuu-api.vercel.app/waifu');
  const [loading, setLoading] = useState(false);

  const generateNew = () => {
    setLoading(true);
    setImageUrl(`https://waifuu-api.vercel.app/waifu?t=${Date.now()}`);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12 relative">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0 relative z-10">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-pink-100 dark:bg-pink-500/10 text-pink-500 rounded-2xl flex items-center justify-center shadow-sm">
            <Heart size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-rose-500">🌸 Waifu Generator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Generate random anime character art instantly.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl flex flex-col items-center">
          <div className="relative w-full max-w-md aspect-square rounded-2xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shadow-inner mb-8 flex items-center justify-center border-4 border-pink-100 dark:border-pink-900/30">
            {loading && <div className="absolute inset-0 flex items-center justify-center bg-white/50 dark:bg-black/50 backdrop-blur-sm z-10"><RefreshCw className="animate-spin text-pink-500" size={40} /></div>}
            <img 
              src={imageUrl} 
              alt="Generated Waifu" 
              className="object-cover w-full h-full"
              onLoad={() => setLoading(false)}
              onError={() => setLoading(false)}
            />
          </div>

          <button 
            onClick={generateNew}
            disabled={loading}
            className="w-full max-w-md py-4 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center gap-3 shadow-lg shadow-pink-500/25"
          >
            {loading ? <RefreshCw className="animate-spin" /> : <Heart className="fill-white" />}
            {loading ? 'Summoning...' : 'Generate New Waifu'}
          </button>
        </div>

        <div className="mt-12 text-center pb-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
