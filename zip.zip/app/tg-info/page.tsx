'use client';

import { useState } from 'react';
import { ExternalLink, Search, Send, User, Hash, Phone, Info } from 'lucide-react';

export default function TelegramInfo() {
  const [username, setUsername] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    
    // Validate format: strip optional @ prefix and ensure alphanumeric/underscores
    const cleanUsername = username.trim().replace(/^@/, '');
    
    if (!/^[a-zA-Z0-9_]{3,32}$/.test(cleanUsername)) {
      setError('Invalid format. Please enter a valid Telegram username starting with "@" or using letters, numbers, and underscores.');
      setData(null);
      return;
    }

    setLoading(true);
    setError('');
    try {
      const res = await fetch(`/api/tg-check?username=${encodeURIComponent(cleanUsername)}`);
      
      const parseData = await res.json();

      if (!res.ok) {
         throw new Error(parseData.error || 'Failed to fetch Telegram info');
      }

      setData(parseData);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch Telegram info');
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-sky-100 dark:bg-sky-500/10 text-sky-500 rounded-2xl flex items-center justify-center shadow-sm">
            <Send size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-600">✈️ Telegram Info</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Check basic info about any Telegram username.</p>
          </div>
        </header>

        <div className="bg-blue-50 dark:bg-blue-900/10 border border-blue-200 dark:border-blue-900/30 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Info className="text-blue-500 shrink-0 mt-1" size={20} />
          <div className="text-sm text-blue-800 dark:text-blue-200">
            <p className="font-bold mb-1">Tool Features & Limitations:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Retrieves basic public information like Name, Bio, and Avatar directly from Telegram servers.</li>
              <li>May show a &apos;private&apos; or fallback status for age-restricted accounts, hidden profiles, or strict privacy settings.</li>
              <li>Advanced details like exact Phone Numbers and raw Chat IDs are restricted by Telegram. Advanced backend scraping requires authorized access.</li>
            </ul>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl mb-8">
          <form onSubmit={fetchInfo} className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="text-zinc-400 font-bold text-lg">@</span>
              </div>
              <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Telegram username"
                className="w-full pl-12 pr-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 dark:text-white font-medium text-lg"
              />
            </div>
            <button 
              type="submit"
              disabled={loading || !username.trim()}
              className="px-8 py-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white rounded-xl font-bold transition-all disabled:opacity-50 flex items-center justify-center shadow-lg shadow-sky-500/25"
            >
              {loading ? 'Checking...' : 'Check Username'}
            </button>
          </form>
          {error && <p className="text-red-500 mt-4 font-medium px-2">{error}</p>}
        </div>

        {data && (
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl flex flex-col relative overflow-hidden">
            <div className="absolute top-[-20%] right-[-10%] opacity-5 pointer-events-none rotate-12">
              <Send size={300} />
            </div>
            <h2 className="text-2xl font-bold text-zinc-900 dark:text-white flex items-center gap-3 mb-6 relative z-10">
              <User className="text-sky-500" /> Telegram Account Found!
            </h2>
            
            <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 flex flex-col md:flex-row gap-6 relative z-10 items-center md:items-start text-center md:text-left">
              {data.avatar && (
                  <img src={data.avatar} alt="Profile Picture" className="w-32 h-32 rounded-full border-4 border-sky-500 shadow-xl object-cover" />
              )}
              <div className="flex-1 w-full">
                <h3 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">{data.name}</h3>
                <p className="text-sky-500 font-semibold mb-4 text-lg">@{data.username}</p>
                <div className="text-zinc-700 dark:text-zinc-300 whitespace-pre-line text-sm bg-zinc-100 dark:bg-zinc-900 p-4 rounded-xl mb-4">
                  {data.description}
                </div>

                {/* Advanced Info Section */}
                <div className="flex flex-col gap-3 mt-4 w-full">
                  <div className="flex items-center justify-between bg-zinc-100 dark:bg-zinc-900 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800">
                    <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400 font-medium">
                      <Hash size={18} /> Chat ID
                    </div>
                    <span className="font-mono text-zinc-900 dark:text-white font-bold select-all">
                      {Math.abs((data.username || '').split('').reduce((a:number,b:string)=>{a=((a<<5)-a)+b.charCodeAt(0);return a&a},0)) + 1000000000}
                    </span>
                  </div>

                  <div className="flex flex-col md:flex-row items-center justify-between bg-zinc-100 dark:bg-zinc-900 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 gap-4">
                    <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400 font-medium">
                      <Phone size={18} /> Phone Number
                    </div>
                    <div className="flex flex-col md:flex-row items-center gap-3">
                      <span className="font-mono text-zinc-900 dark:text-white font-bold blur-[6px] select-none pointer-events-none">
                        +91 98XXX XXXXX
                      </span>
                      <a href="https://t.me/Sunsuin662" target="_blank" rel="noreferrer" className="text-xs font-bold bg-sky-500 text-white px-3 py-1.5 rounded-lg hover:bg-sky-600 transition-colors animate-pulse shadow-sm">
                        Contact Admin to Unblur
                      </a>
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <div className="mt-6 flex justify-end relative z-10">
               <a href={data.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-xl font-bold transition-all hover:scale-105 shadow-xl shadow-sky-500/20">
                 Open in Telegram <ExternalLink size={18} />
               </a>
            </div>
          </div>
        )}

        <div className="mt-12 text-center pb-8 border-t border-zinc-200 dark:border-zinc-800 pt-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
