'use client';

import { useState } from 'react';
import { BookOpen, PenTool, Copy, Check } from 'lucide-react';

export default function AIStoryGenerator() {
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;
    setGenerating(true);
    setTimeout(() => {
      setResult(`Once upon a time, in a world where ${prompt.toLowerCase()}, there lived a curious adventurer. Every day brought new challenges and unexpected discoveries. The journey was long, but the lessons learned were invaluable. As the sun set on the horizon, a new chapter was just beginning to unfold...`);
      setGenerating(false);
    }, 2000);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center shadow-sm">
            <BookOpen size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">AI Story Generator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Generate creative stories from a simple prompt.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={handleGenerate} className="mb-8">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="What is your story about? (e.g., A robot learning to paint)"
              className="w-full px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 dark:text-white text-lg min-h-[120px] resize-none mb-4"
            />
            <button 
              type="submit"
              disabled={generating || !prompt}
              className="w-full py-4 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white rounded-xl font-bold transition-colors flex items-center justify-center gap-2"
            >
              {generating ? <PenTool className="animate-spin" /> : <PenTool />}
              Write Story
            </button>
          </form>

          {result && (
            <div className="p-6 bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800/50 rounded-2xl relative">
              <button 
                onClick={copyToClipboard}
                className="absolute top-4 right-4 p-2 bg-white dark:bg-zinc-800 rounded-lg shadow-sm text-zinc-500 hover:text-amber-600 transition-colors"
              >
                {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
              </button>
              <p className="text-zinc-800 dark:text-zinc-200 leading-relaxed whitespace-pre-wrap pr-10">
                {result}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
