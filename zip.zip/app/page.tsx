'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, Image as ImageIcon, Video, Download, Instagram, QrCode, ArrowRight, FileText, Key, Type, Mail, Sparkles, Shield, Zap,
  DollarSign, Scale, Activity, Calendar, Code, Hash, Fingerprint, AlignLeft, Palette, Volume2, Timer, ListTodo, FileEdit, ImageMinus, Link as LinkIcon,
  Wand2, BookOpen, Code2, Youtube, Music, Twitter, Facebook, MessageCircle, CheckSquare, Wallet, Unlock, FileCode2
} from 'lucide-react';
import { DynamicBackground } from '@/components/DynamicBackground';
import { useAdmin } from '@/components/AdminProvider';

const tools = [
  // AI Generation (8)
  { id: 'chat', name: '🤖 AI Chat', category: 'AI Generation', href: '/chat', icon: MessageSquare, description: 'Chat with an advanced AI model for answers and assistance.', color: 'text-blue-500 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-400/10' },
  { id: 'videoGen', name: '🎬 AI Video Gen', category: 'AI Generation', href: '/video-gen', icon: Video, description: 'Create short videos from text prompts instantly.', color: 'text-pink-500 dark:text-pink-400', bg: 'bg-pink-100 dark:bg-pink-400/10' },
  { id: 'wpGen', name: '📝 WP Post Gen', category: 'AI Generation', href: '/wp-generator', icon: FileText, description: 'Generate SEO-optimized blog posts for WordPress.', color: 'text-cyan-500 dark:text-cyan-400', bg: 'bg-cyan-100 dark:bg-cyan-400/10' },
  { id: 'textToSpeech', name: '🗣️ Text to Speech', category: 'AI Generation', href: '/text-to-speech', icon: Volume2, description: 'Convert text into natural sounding speech.', color: 'text-sky-500 dark:text-sky-400', bg: 'bg-sky-100 dark:bg-sky-400/10' },
  { id: 'aiImage', name: '🎨 AI Image Gen', category: 'AI Generation', href: '/ai-image', icon: Wand2, description: 'Transform your text into stunning visuals.', color: 'text-purple-500 dark:text-purple-400', bg: 'bg-purple-100 dark:bg-purple-400/10' },
  { id: 'aiStory', name: '📖 AI Story Gen', category: 'AI Generation', href: '/ai-story', icon: BookOpen, description: 'Generate creative stories from a simple prompt.', color: 'text-amber-500 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-400/10' },
  { id: 'aiCode', name: '💻 AI Code Assist', category: 'AI Generation', href: '/ai-code', icon: Code2, description: 'Generate code snippets from natural language.', color: 'text-blue-600 dark:text-blue-500', bg: 'bg-blue-200 dark:bg-blue-500/10' },
  { id: 'aiPrompt', name: '✨ AI Prompt Builder', category: 'AI Generation', href: '/ai-prompt', icon: Sparkles, description: 'Craft the perfect prompt for ChatGPT or Claude.', color: 'text-indigo-500 dark:text-indigo-400', bg: 'bg-indigo-100 dark:bg-indigo-400/10' },

  // Downloaders (8)
  { id: 'videoDl', name: '⬇️ Universal DL', category: 'Downloaders', href: '/video-dl', icon: Download, description: 'Download videos from YouTube, Facebook, TikTok, and more.', color: 'text-emerald-500 dark:text-emerald-400', bg: 'bg-emerald-100 dark:bg-emerald-400/10' },
  { id: 'instaDl', name: '📸 Insta DL', category: 'Downloaders', href: '/insta-dl', icon: Instagram, description: 'Save Instagram Reels and Posts directly to your device.', color: 'text-orange-500 dark:text-orange-400', bg: 'bg-orange-100 dark:bg-orange-400/10' },
  { id: 'ytDl', name: '▶️ YouTube DL', category: 'Downloaders', href: '/yt-dl', icon: Youtube, description: 'Download videos and audio from YouTube.', color: 'text-red-500 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-400/10' },
  { id: 'tiktokDl', name: '🎵 TikTok DL', category: 'Downloaders', href: '/tiktok-dl', icon: Music, description: 'Download TikTok videos without watermark.', color: 'text-zinc-800 dark:text-zinc-200', bg: 'bg-zinc-200 dark:bg-zinc-800/50' },
  { id: 'twitterDl', name: '🐦 Twitter DL', category: 'Downloaders', href: '/twitter-dl', icon: Twitter, description: 'Download videos and GIFs from Twitter/X.', color: 'text-sky-500 dark:text-sky-400', bg: 'bg-sky-100 dark:bg-sky-400/10' },
  { id: 'fbDl', name: '📘 Facebook DL', category: 'Downloaders', href: '/fb-dl', icon: Facebook, description: 'Download public videos from Facebook.', color: 'text-blue-600 dark:text-blue-500', bg: 'bg-blue-200 dark:bg-blue-500/10' },
  { id: 'pinterestDl', name: '📌 Pinterest DL', category: 'Downloaders', href: '/pinterest-dl', icon: ImageIcon, description: 'Download images and videos from Pinterest.', color: 'text-red-600 dark:text-red-500', bg: 'bg-red-100 dark:bg-red-500/10' },
  { id: 'redditDl', name: '🔥 Reddit DL', category: 'Downloaders', href: '/reddit-dl', icon: MessageCircle, description: 'Download videos with audio from Reddit.', color: 'text-orange-600 dark:text-orange-500', bg: 'bg-orange-200 dark:bg-orange-500/10' },

  // Productivity (8)
  { id: 'todoList', name: '📋 To-Do List', category: 'Productivity', href: '/todo-list', icon: ListTodo, description: 'Manage your daily tasks and stay organized.', color: 'text-teal-500 dark:text-teal-400', bg: 'bg-teal-100 dark:bg-teal-400/10' },
  { id: 'notepad', name: '📝 Notepad', category: 'Productivity', href: '/notepad', icon: FileEdit, description: 'Quick online notepad for temporary notes.', color: 'text-amber-600 dark:text-amber-500', bg: 'bg-amber-100 dark:bg-amber-500/10' },
  { id: 'wordCounter', name: '🔢 Word Counter', category: 'Productivity', href: '/word-counter', icon: Type, description: 'Count words, characters, and reading time.', color: 'text-amber-500 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-400/10' },
  { id: 'loremIpsum', name: '📃 Lorem Ipsum', category: 'Productivity', href: '/lorem-ipsum', icon: AlignLeft, description: 'Generate placeholder text for your designs.', color: 'text-stone-500 dark:text-stone-400', bg: 'bg-stone-100 dark:bg-stone-400/10' },
  { id: 'pomodoro', name: '🍅 Pomodoro', category: 'Productivity', href: '/pomodoro', icon: Timer, description: 'Boost your productivity with timed focus sessions.', color: 'text-red-500 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-400/10' },
  { id: 'markdown', name: '👀 Markdown Editor', category: 'Productivity', href: '/markdown', icon: FileCode2, description: 'Write and preview markdown instantly.', color: 'text-blue-500 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-400/10' },
  { id: 'habitTracker', name: '✅ Habit Tracker', category: 'Productivity', href: '/habit-tracker', icon: CheckSquare, description: 'Build good habits and track your daily streaks.', color: 'text-emerald-500 dark:text-emerald-400', bg: 'bg-emerald-100 dark:bg-emerald-400/10' },
  { id: 'expenseTracker', name: '💰 Expense Tracker', category: 'Productivity', href: '/expense-tracker', icon: Wallet, description: 'Keep track of your daily expenses easily.', color: 'text-green-600 dark:text-green-500', bg: 'bg-green-200 dark:bg-green-500/10' },

  // Utilities (8)
  { id: 'qr', name: '🔲 QR Generator', category: 'Utilities', href: '/qr', icon: QrCode, description: 'Generate custom QR codes for any link or text.', color: 'text-indigo-500 dark:text-indigo-400', bg: 'bg-indigo-100 dark:bg-indigo-400/10' },
  { id: 'passwordGen', name: '🔑 Password Gen', category: 'Utilities', href: '/password-gen', icon: Key, description: 'Create strong, secure passwords instantly.', color: 'text-rose-500 dark:text-rose-400', bg: 'bg-rose-100 dark:bg-rose-400/10' },
  { id: 'tempMail', name: '📧 Temp Mail', category: 'Utilities', href: '/temp-mail', icon: Mail, description: 'Generate a disposable email address for OTPs.', color: 'text-blue-500 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-400/10' },
  { id: 'currencyConverter', name: '💱 Currency Conv', category: 'Utilities', href: '/currency-converter', icon: DollarSign, description: 'Convert between different global currencies.', color: 'text-green-500 dark:text-green-400', bg: 'bg-green-100 dark:bg-green-400/10' },
  { id: 'unitConverter', name: '⚖️ Unit Converter', category: 'Utilities', href: '/unit-converter', icon: Scale, description: 'Convert length, weight, temperature, and more.', color: 'text-violet-500 dark:text-violet-400', bg: 'bg-violet-100 dark:bg-violet-400/10' },
  { id: 'bmiCalculator', name: '⚕️ BMI Calculator', category: 'Utilities', href: '/bmi-calculator', icon: Activity, description: 'Calculate your Body Mass Index quickly.', color: 'text-red-500 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-400/10' },
  { id: 'ageCalculator', name: '🎂 Age Calculator', category: 'Utilities', href: '/age-calculator', icon: Calendar, description: 'Calculate exact age in years, months, and days.', color: 'text-blue-400 dark:text-blue-300', bg: 'bg-blue-50 dark:bg-blue-300/10' },
  { id: 'stopwatch', name: '⏱️ Stopwatch', category: 'Utilities', href: '/stopwatch', icon: Timer, description: 'Simple online stopwatch with lap times.', color: 'text-orange-400 dark:text-orange-300', bg: 'bg-orange-50 dark:bg-orange-300/10' },

  // Developer Tools (8)
  { id: 'jsonFormatter', name: '>{</> JSON Formatter', category: 'Developer Tools', href: '/json-formatter', icon: Code, description: 'Format and validate JSON data easily.', color: 'text-yellow-500 dark:text-yellow-400', bg: 'bg-yellow-100 dark:bg-yellow-400/10' },
  { id: 'base64', name: '🏷️ Base64 Encoder', category: 'Developer Tools', href: '/base64', icon: Hash, description: 'Encode and decode Base64 strings.', color: 'text-slate-500 dark:text-slate-400', bg: 'bg-slate-100 dark:bg-slate-400/10' },
  { id: 'hashGen', name: '🛡️ Hash Generator', category: 'Developer Tools', href: '/hash-gen', icon: Fingerprint, description: 'Generate MD5, SHA-1, and SHA-256 hashes.', color: 'text-zinc-500 dark:text-zinc-400', bg: 'bg-zinc-100 dark:bg-zinc-400/10' },
  { id: 'colorPicker', name: '🎨 Color Picker', category: 'Developer Tools', href: '/color-picker', icon: Palette, description: 'Pick colors and get HEX, RGB, and HSL codes.', color: 'text-fuchsia-500 dark:text-fuchsia-400', bg: 'bg-fuchsia-100 dark:bg-fuchsia-400/10' },
  { id: 'imageCompressor', name: '🗜️ Image Compress', category: 'Developer Tools', href: '/image-compressor', icon: ImageMinus, description: 'Compress images to reduce file size.', color: 'text-indigo-400 dark:text-indigo-300', bg: 'bg-indigo-50 dark:bg-indigo-300/10' },
  { id: 'urlShortener', name: '🔗 URL Shortener', category: 'Developer Tools', href: '/url-shortener', icon: LinkIcon, description: 'Shorten long URLs for easy sharing.', color: 'text-blue-600 dark:text-blue-500', bg: 'bg-blue-200 dark:bg-blue-500/10' },
  { id: 'jwtDecoder', name: '🔓 JWT Decoder', category: 'Developer Tools', href: '/jwt-decoder', icon: Unlock, description: 'Decode JSON Web Tokens instantly.', color: 'text-pink-600 dark:text-pink-500', bg: 'bg-pink-200 dark:bg-pink-500/10' },
  { id: 'cssGradient', name: '🌈 CSS Gradient', category: 'Developer Tools', href: '/css-gradient', icon: Palette, description: 'Create beautiful CSS gradients easily.', color: 'text-indigo-500 dark:text-indigo-400', bg: 'bg-indigo-100 dark:bg-indigo-400/10' },
  
  // Fun & Social (4)
  { id: 'waifuGen', name: '🌸 Waifu Gen', category: 'Fun & Social', href: '/waifu', icon: ImageIcon, description: 'Generate random Anime Waifu images directly.', color: 'text-pink-500 dark:text-pink-400', bg: 'bg-pink-100 dark:bg-pink-400/10' },
  { id: 'memeGen', name: '😂 Meme Gen', category: 'Fun & Social', href: '/meme', icon: ImageIcon, description: 'Generate random hilarious memes.', color: 'text-yellow-500 dark:text-yellow-400', bg: 'bg-yellow-100 dark:bg-yellow-400/10' },
  { id: 'githubInfo', name: '🐙 GitHub Info', category: 'Fun & Social', href: '/github-info', icon: Hash, description: 'Get detailed info about any GitHub user.', color: 'text-slate-700 dark:text-slate-300', bg: 'bg-slate-200 dark:bg-slate-700/50' },
  { id: 'tgInfo', name: '✈️ TG Info', category: 'Fun & Social', href: '/tg-info', icon: MessageCircle, description: 'Get basic info about Telegram users.', color: 'text-sky-500 dark:text-sky-400', bg: 'bg-sky-100 dark:bg-sky-400/10' },
];

const categories = ['All', 'AI Generation', 'Downloaders', 'Productivity', 'Utilities', 'Developer Tools', 'Fun & Social'];

export default function Home() {
  const { tools: adminTools } = useAdmin();
  const [hasEntered, setHasEntered] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  if (!hasEntered) {
    return (
      <div 
        className="fixed inset-0 z-[100] bg-[#030014] flex flex-col items-center justify-center cursor-pointer overflow-hidden perspective-1000" 
        onClick={() => setHasEntered(true)}
      >
        {/* Deep Space Background */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-[#030014] to-[#030014]"></div>
        
        {/* 3D Rotating Rings System */}
        <div className="absolute inset-0 flex items-center justify-center transform-style-3d">
          {/* Outer Ring */}
          <div className="absolute w-[150vw] h-[150vw] md:w-[120vw] md:h-[120vw] border-[2px] border-blue-500/10 rounded-full animate-[spin_60s_linear_infinite] shadow-[inset_0_0_100px_rgba(59,130,246,0.1)]" style={{ transform: 'rotateX(75deg) rotateY(10deg) translateZ(-200px)' }}></div>
          
          {/* Middle Ring */}
          <div className="absolute w-[120vw] h-[120vw] md:w-[90vw] md:h-[90vw] border-[2px] border-purple-500/20 rounded-full animate-[spin_40s_linear_infinite_reverse] shadow-[0_0_80px_rgba(168,85,247,0.15)]" style={{ transform: 'rotateX(65deg) rotateY(-15deg) translateZ(-100px)' }}></div>
          
          {/* Inner Glowing Ring */}
          <div className="absolute w-[90vw] h-[90vw] md:w-[60vw] md:h-[60vw] border-[3px] border-cyan-400/30 rounded-full animate-[spin_20s_linear_infinite] shadow-[0_0_120px_rgba(34,211,238,0.2)]" style={{ transform: 'rotateX(80deg) rotateY(25deg) translateZ(0px)' }}></div>
          
          {/* Core Energy Sphere */}
          <div className="absolute w-64 h-64 bg-blue-600/5 rounded-full filter blur-[80px] animate-pulse" style={{ animationDuration: '4s' }}></div>
        </div>
        
        {/* Floating Particles */}
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at center, #fff 1px, transparent 1px)', backgroundSize: '100px 100px', animation: 'moveStars 20s linear infinite' }}></div>
        
        {/* Main Content */}
        <div className="relative z-10 flex flex-col items-center transform transition-transform duration-700 hover:scale-105">
          {/* Logo Mark */}
          <div className="w-28 h-28 md:w-36 md:h-36 bg-gradient-to-br from-blue-500 via-indigo-600 to-purple-600 rounded-[2rem] flex items-center justify-center shadow-[0_0_80px_rgba(79,70,229,0.6)] mb-10 animate-bounce" style={{ animationDuration: '3s' }}>
            <div className="w-full h-full rounded-[2rem] border border-white/20 flex items-center justify-center bg-white/10 backdrop-blur-sm">
              <span className="text-5xl md:text-7xl font-black text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]">R</span>
            </div>
          </div>
          
          {/* Typography */}
          <h1 className="text-6xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-white/90 to-white/20 tracking-tighter text-center drop-shadow-[0_0_30px_rgba(255,255,255,0.2)]">
            RUDRA <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">API</span>
          </h1>
          
          {/* Interactive Prompt */}
          <div className="mt-12 group flex flex-col items-center">
            <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center mb-4 animate-pulse bg-white/5 backdrop-blur-md">
              <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
            <p className="text-blue-300/80 tracking-[0.4em] uppercase text-xs md:text-sm font-bold group-hover:text-white transition-colors duration-300">
              Click Anywhere To Initialize
            </p>
          </div>
        </div>

        <style jsx>{`
          .perspective-1000 { perspective: 1000px; }
          .transform-style-3d { transform-style: preserve-3d; }
          @keyframes moveStars {
            from { transform: translateY(0) scale(1); opacity: 0; }
            50% { opacity: 0.3; }
            to { transform: translateY(-100px) scale(1.5); opacity: 0; }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto relative">
      <DynamicBackground />
      
      <div className="relative z-10 p-6 md:p-12 min-h-full flex flex-col">
        <div className="max-w-7xl mx-auto w-full flex-1 flex flex-col">
          
          {/* Hero Section */}
          <header className="mb-16 mt-12 md:mt-8 text-center flex flex-col items-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 dark:bg-zinc-900/50 backdrop-blur-md border border-white/20 dark:border-zinc-800 mb-8 shadow-sm">
              <Sparkles size={16} className="text-blue-500" />
              <span className="text-sm font-medium text-zinc-800 dark:text-zinc-200">Next-Gen Enterprise Tools</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-6 text-zinc-900 dark:text-white drop-shadow-sm leading-tight">
              Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-500">OmniTools</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-zinc-700 dark:text-zinc-300 max-w-3xl drop-shadow-sm font-medium leading-relaxed mb-10">
              Your all-in-one platform for AI generation, digital utilities, and secure operations. 
              <span className="block mt-2 text-blue-600 dark:text-blue-400">No sign-up required. 100% free.</span>
            </p>

            <div className="flex flex-wrap justify-center gap-4 text-sm font-medium text-zinc-600 dark:text-zinc-400">
              <div className="flex items-center gap-2 bg-white/50 dark:bg-zinc-900/50 px-4 py-2 rounded-lg backdrop-blur-sm border border-zinc-200/50 dark:border-zinc-800/50">
                <Zap size={16} className="text-amber-500" /> Lightning Fast
              </div>
              <div className="flex items-center gap-2 bg-white/50 dark:bg-zinc-900/50 px-4 py-2 rounded-lg backdrop-blur-sm border border-zinc-200/50 dark:border-zinc-800/50">
                <Shield size={16} className="text-emerald-500" /> Secure & Private
              </div>
            </div>
          </header>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all duration-300 ${
                  activeCategory === cat 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25 scale-105' 
                    : 'bg-white/50 dark:bg-zinc-900/50 text-zinc-600 dark:text-zinc-400 hover:bg-white dark:hover:bg-zinc-800 backdrop-blur-sm border border-zinc-200/50 dark:border-zinc-800/50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Tools Grid by Category */}
          <div className="pb-12 space-y-16">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeCategory}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-16"
              >
                {categories.filter(c => c !== 'All' && (activeCategory === 'All' || activeCategory === c)).map(category => {
                  const categoryTools = tools.filter(t => t.category === category);
                  if (categoryTools.length === 0) return null;

                  return (
                    <div key={category}>
                      <h2 className="text-3xl font-black text-zinc-900 dark:text-white mb-8 flex items-center gap-3">
                        <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                        {category}
                      </h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {categoryTools.map((tool) => {
                          const Icon = tool.icon;
                          const isEnabled = adminTools[tool.id] !== false;

                          if (!isEnabled) {
                            return (
                              <motion.div 
                                layout
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 0.6, scale: 1 }}
                                key={tool.name} 
                                className="group relative flex flex-col p-8 bg-zinc-200/40 dark:bg-zinc-900/40 backdrop-blur-xl border border-zinc-300/50 dark:border-zinc-800/50 rounded-3xl cursor-not-allowed overflow-hidden"
                              >
                                <div className="absolute top-5 right-5 bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400 text-xs font-bold px-3 py-1.5 rounded-full shadow-sm">
                                  Off by Admin
                                </div>
                                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 bg-zinc-300 dark:bg-zinc-800 grayscale shadow-inner`}>
                                  <Icon size={28} className="text-zinc-500" />
                                </div>
                                <h3 className="text-2xl font-bold mb-3 text-zinc-500 dark:text-zinc-400">{tool.name}</h3>
                                <p className="text-zinc-400 dark:text-zinc-500 text-base leading-relaxed flex-1">
                                  {tool.description}
                                </p>
                              </motion.div>
                            );
                          }

                          return (
                            <motion.div layout initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} key={tool.name}>
                              <Link 
                                href={tool.href}
                                className="group relative flex flex-col p-8 bg-white/70 dark:bg-zinc-900/70 backdrop-blur-xl border border-zinc-200/50 dark:border-zinc-700/50 rounded-3xl hover:bg-white dark:hover:bg-zinc-800 transition-all duration-500 hover:border-blue-500/30 dark:hover:border-blue-500/30 shadow-lg hover:shadow-xl hover:-translate-y-1 overflow-hidden h-full"
                              >
                                {/* Hover Gradient Background */}
                                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                                
                                <div className="relative z-10 flex flex-col h-full">
                                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 shadow-inner transition-transform duration-500 group-hover:scale-110 ${tool.bg}`}>
                                    <Icon size={28} className={tool.color} />
                                  </div>
                                  <h3 className="text-2xl font-bold mb-3 text-zinc-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{tool.name}</h3>
                                  <p className="text-zinc-600 dark:text-zinc-400 text-base leading-relaxed flex-1 mb-8">
                                    {tool.description}
                                  </p>
                                  
                                  <div className="flex items-center text-sm font-bold text-zinc-800 dark:text-zinc-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors mt-auto pt-4 border-t border-zinc-200/50 dark:border-zinc-800/50">
                                    Launch Tool 
                                    <ArrowRight size={18} className="ml-2 group-hover:translate-x-2 transition-transform duration-300" />
                                  </div>
                                </div>
                              </Link>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </motion.div>
            </AnimatePresence>
          </div>
          
          <div className="mt-20 text-center pb-10 border-t border-zinc-200 dark:border-zinc-800 pt-16">
            <p className="text-zinc-500 dark:text-zinc-400 font-bold uppercase tracking-widest text-sm mb-2">Platform Architect & Lead Engineer</p>
            <h2 className="text-4xl font-black mt-2 text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 drop-shadow-sm">
              Developed by Shatarudra
            </h2>
            <div className="flex justify-center mt-6 gap-6">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-bounce"></span>
              <span className="w-2 h-2 bg-orange-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
              <span className="w-2 h-2 bg-yellow-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
