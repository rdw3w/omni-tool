'use client';

import { useState, useEffect } from 'react';
import { FileEdit, Save, Trash2 } from 'lucide-react';

export default function Notepad() {
  const [text, setText] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const savedText = localStorage.getItem('notepad_text');
    if (savedText) {
      setText(savedText);
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('notepad_text', text);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleClear = () => {
    if (confirm('Are you sure you want to clear your notes?')) {
      setText('');
      localStorage.removeItem('notepad_text');
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0 h-full flex flex-col">
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center shadow-sm">
              <FileEdit size={32} />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Notepad</h1>
              <p className="text-zinc-500 dark:text-zinc-400 mt-1">Quick online notes (saves to browser).</p>
            </div>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={handleClear}
              className="px-4 py-2 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-500/20 rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <Trash2 size={18} />
              Clear
            </button>
            <button 
              onClick={handleSave}
              className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <Save size={18} />
              {saved ? 'Saved!' : 'Save'}
            </button>
          </div>
        </header>

        <div className="flex-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl shadow-sm overflow-hidden flex flex-col min-h-[500px]">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Start typing your notes here..."
            className="flex-1 w-full p-8 bg-transparent focus:outline-none dark:text-white text-lg resize-none leading-relaxed"
            style={{ 
              backgroundImage: 'linear-gradient(transparent, transparent 31px, #e5e7eb 31px, #e5e7eb 32px)',
              backgroundSize: '100% 32px',
              lineHeight: '32px'
            }}
          />
        </div>
      </div>
    </div>
  );
}
