'use client';

import { useState } from 'react';
import { Palette, Copy, Check } from 'lucide-react';

export default function ColorPicker() {
  const [color, setColor] = useState('#4f46e5');
  const [copied, setCopied] = useState('');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(text);
    setTimeout(() => setCopied(''), 2000);
  };

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? 
      `rgb(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)})` : null;
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-2xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-fuchsia-100 dark:bg-fuchsia-500/10 text-fuchsia-600 dark:text-fuchsia-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Palette size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Color Picker</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Pick colors and get HEX and RGB values.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div className="flex flex-col items-center space-y-8">
            <div 
              className="w-48 h-48 rounded-full shadow-inner border-4 border-white dark:border-zinc-800 transition-colors duration-200"
              style={{ backgroundColor: color }}
            />
            
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="w-full h-12 rounded-lg cursor-pointer"
            />

            <div className="w-full space-y-4">
              <div className="flex justify-between items-center p-4 bg-zinc-50 dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800">
                <span className="font-mono text-zinc-900 dark:text-white">{color.toUpperCase()}</span>
                <button 
                  onClick={() => copyToClipboard(color.toUpperCase())}
                  className="text-zinc-500 hover:text-fuchsia-500 transition-colors"
                >
                  {copied === color.toUpperCase() ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
                </button>
              </div>
              
              <div className="flex justify-between items-center p-4 bg-zinc-50 dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800">
                <span className="font-mono text-zinc-900 dark:text-white">{hexToRgb(color) || 'Invalid'}</span>
                <button 
                  onClick={() => copyToClipboard(hexToRgb(color) || '')}
                  className="text-zinc-500 hover:text-fuchsia-500 transition-colors"
                >
                  {copied === hexToRgb(color) ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
