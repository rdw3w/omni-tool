'use client';

import { useState } from 'react';
import { Download, Twitter, Link as LinkIcon, RefreshCw, Video, Info } from 'lucide-react';

export default function TwitterDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true);
    setResult(null);
    
    try {
      const res = await fetch(`/api/twitter-dl?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || 'Failed to fetch media');
      
      setResult(data);
    } catch (err: any) {
      setResult({
        error: err.message
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12 relative">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0 relative z-10">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-sky-100 dark:bg-sky-500/10 text-sky-500 rounded-2xl flex items-center justify-center shadow-sm">
            <Twitter size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-600">🐦 Twitter Downloader</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Download videos and GIFs from Twitter/X effortlessly.</p>
          </div>
        </header>

        <div className="bg-sky-500/10 border border-sky-500/20 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Info className="text-sky-500 shrink-0 mt-1" size={20} />
          <div className="text-sm text-sky-700 dark:text-sky-200">
            <p className="font-bold mb-1">Tool Features & Limitations:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Fetches clean video streams and images from any public X/Twitter link.</li>
              <li>Supports multi-media tweets (multiple videos or pictures).</li>
              <li>Tweets from protected/locked accounts cannot be downloaded.</li>
            </ul>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl">
          <form onSubmit={handleDownload} className="flex flex-col gap-4 mb-8">
            <div className="relative">
               <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                 <LinkIcon className="text-zinc-400" size={20} />
               </div>
               <input 
                 type="url"
                 value={url}
                 onChange={(e) => setUrl(e.target.value)}
                 placeholder="Paste Twitter URL (e.g. https://x.com/...)"
                 className="w-full pl-12 pr-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 dark:text-white font-medium text-lg"
                 required
               />
            </div>
            <button 
              type="submit"
              disabled={loading || !url}
              className="w-full py-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-sky-500/25"
            >
              {loading ? <RefreshCw className="animate-spin" /> : <Download />}
              {loading ? 'Fetching Media...' : 'Download Media'}
            </button>
          </form>

          {result && result.error && (
             <div className="mt-8 p-4 bg-red-100 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30 text-red-600 dark:text-red-400 rounded-xl font-medium text-center">
               {result.error}
             </div>
          )}

          {result && result.success && (
            <div className="mt-8 border-t border-zinc-200 dark:border-zinc-800 pt-8 flex flex-col items-center">
                <div className="w-full flex flex-col items-center gap-6">
                  <div className="w-full rounded-2xl overflow-hidden shadow-inner border border-sky-100 dark:border-sky-900/20 bg-zinc-50 dark:bg-zinc-800/50 p-6 flex flex-col items-center text-center">
                     <Video className="text-sky-500 mb-4" size={48} />
                     <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-2">{result.title}</h3>
                     {result.author && <p className="text-sky-500 font-medium mb-4">@{result.author}</p>}
                     <p className="text-zinc-600 dark:text-zinc-400 mb-6">{result.message}</p>
                     
                     {result.media && result.media.length > 0 && (
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                          {result.media.map((m: any, idx: number) => (
                             <div key={idx} className="bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 flex flex-col items-center gap-4">
                                <img src={m.thumbnail} alt="thumbnail" className="w-full h-32 object-cover rounded-lg" />
                                <a href={m.url} target="_blank" rel="noreferrer" className="w-full py-3 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white rounded-lg font-bold transition-all flex items-center justify-center gap-2 shadow-md">
                                  <Download size={18} /> Download {m.type === 'video' ? 'Video' : 'Image'}
                                </a>
                             </div>
                          ))}
                       </div>
                     )}
                  </div>
                </div>
            </div>
          )}
        </div>

        <div className="mt-12 text-center pb-8 pt-8">
          <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Developer</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
