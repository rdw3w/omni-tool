'use client';

import { useState } from 'react';
import { ImageMinus, Upload, Download } from 'lucide-react';

export default function ImageCompressor() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shadow-sm">
            <ImageMinus size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Image Compressor</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Compress images to reduce file size (Mock UI).</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          {!file ? (
            <div className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-2xl p-12 flex flex-col items-center justify-center text-center hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors cursor-pointer relative">
              <input 
                type="file" 
                accept="image/*" 
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <Upload size={48} className="text-zinc-400 mb-4" />
              <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2">Upload Image</h3>
              <p className="text-zinc-500 dark:text-zinc-400">Drag and drop or click to select an image</p>
            </div>
          ) : (
            <div className="space-y-8">
              <div className="flex flex-col md:flex-row gap-8 items-center">
                <div className="flex-1 w-full">
                  <h3 className="text-lg font-semibold text-zinc-900 dark:text-white mb-4 text-center">Original</h3>
                  <div className="aspect-square rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 flex items-center justify-center">
                    {preview && <img src={preview} alt="Original" className="max-w-full max-h-full object-contain" />}
                  </div>
                  <p className="text-center text-zinc-500 mt-2 text-sm">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
                <div className="flex-1 w-full">
                  <h3 className="text-lg font-semibold text-zinc-900 dark:text-white mb-4 text-center">Compressed (Preview)</h3>
                  <div className="aspect-square rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 flex items-center justify-center opacity-80">
                    {preview && <img src={preview} alt="Compressed" className="max-w-full max-h-full object-contain" />}
                  </div>
                  <p className="text-center text-green-500 mt-2 text-sm font-medium">~{((file.size * 0.4) / 1024 / 1024).toFixed(2)} MB (-60%)</p>
                </div>
              </div>
              
              <div className="flex gap-4 justify-center">
                <button 
                  onClick={() => { setFile(null); setPreview(null); }}
                  className="px-6 py-3 bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 rounded-xl font-medium transition-colors"
                >
                  Start Over
                </button>
                <button 
                  className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors flex items-center gap-2"
                >
                  <Download size={20} />
                  Download Compressed
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
