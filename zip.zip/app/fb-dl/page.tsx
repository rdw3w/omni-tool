'use client';

import { useState } from 'react';
import { Facebook, Download, Info } from 'lucide-react';

export default function FacebookDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const [result, setResult] = useState<any>(null);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch('/api/universal-dl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to download media");
      setResult(data);
    } catch (e: any) {
       setResult({ error: e.message || "Failed to download media" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0 relative z-10">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 dark:bg-blue-500/10 text-blue-600 rounded-2xl flex items-center justify-center shadow-sm">
            <Facebook size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Facebook Downloader</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Download public videos from Facebook.</p>
          </div>
        </header>

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Info className="text-blue-500 shrink-0 mt-1" size={20} />
          <div className="text-sm text-blue-700 dark:text-blue-200">
            <p className="font-bold mb-1">Tool Features & Limitations:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Downloads videos from public Facebook pages, profiles, and open groups.</li>
              <li>Does not support Reels or Videos from private, closed groups.</li>
              <li>Provides the highest available resolution up to 1080p where supported.</li>
            </ul>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={handleDownload} className="flex flex-col gap-4">
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste Facebook Video URL here..."
              className="w-full px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white text-lg"
              required
            />
            <button 
              type="submit"
              disabled={loading || !url}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl font-bold transition-colors flex items-center justify-center gap-2"
            >
              {loading ? <Download className="animate-bounce" /> : <Download />}
              {loading ? 'Processing...' : 'Download Video'}
            </button>
          </form>

          {result && (
            <div className="mt-8 border-t border-zinc-200 dark:border-zinc-800 pt-8 flex flex-col items-center">
              {result.error ? (
                 <p className="text-red-500 font-bold">{result.error}</p>
              ) : (
                <div className="w-full flex flex-col items-center gap-6">
                  {result.url && (
                    <video src={result.url} controls className="w-full max-w-sm rounded-xl border border-zinc-200 dark:border-zinc-800" />
                  )}
                  {result.picker && Array.isArray(result.picker) && (
                     <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                       {result.picker.map((item: any, idx: number) => (
                          <div key={idx} className="flex flex-col items-center gap-2">
                            <img src={item.thumb} alt="thumbnail" className="w-full h-24 object-cover rounded-md bg-zinc-200" />
                            <a href={item.url} target="_blank" rel="noreferrer" className="w-full text-center py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-bold">DL {idx + 1}</a>
                          </div>
                       ))}
                     </div>
                  )}
                  {result.url && (
                    <a href={result.url} target="_blank" rel="noreferrer" className="w-full max-w-sm py-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-900 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg">
                      <Download size={20} /> Download Media
                    </a>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
