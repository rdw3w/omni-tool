'use client';

import { BackButton } from '@/components/BackButton';
import { BookOpen, Code, Terminal, Zap } from 'lucide-react';

export default function DocsPage() {
  return (
    <div className="flex flex-col h-full overflow-y-auto bg-white dark:bg-zinc-950 p-6 md:p-12 transition-colors duration-300">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        
        <header className="mb-12 border-b border-zinc-200 dark:border-zinc-800 pb-8">
          <div className="w-16 h-16 bg-blue-100 dark:bg-blue-500/10 text-blue-500 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6">
            <BookOpen size={32} />
          </div>
          <h1 className="text-4xl font-extrabold mb-4 text-zinc-900 dark:text-white">Rudra API Documentation</h1>
          <p className="text-xl text-zinc-600 dark:text-zinc-400">
            Learn how to integrate OmniTools capabilities directly into your applications.
          </p>
        </header>

        <div className="space-y-12">
          {/* Section 1 */}
          <section>
            <h2 className="text-2xl font-bold mb-4 text-zinc-900 dark:text-white flex items-center gap-2">
              <Zap className="text-blue-500" /> Getting Started
            </h2>
            <p className="text-zinc-700 dark:text-zinc-300 mb-4 leading-relaxed">
              The Rudra API provides programmatic access to all the tools available on the OmniTools Hub. 
              To use the API, you need an API key. You can purchase a lifetime Enterprise Token for $1000 from the Pricing page.
            </p>
            <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4">
              <p className="text-sm font-mono text-zinc-800 dark:text-zinc-300">
                Base URL: <span className="text-blue-500">https://api.rudra-omnitools.com/v1</span>
              </p>
            </div>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-2xl font-bold mb-4 text-zinc-900 dark:text-white flex items-center gap-2">
              <Code className="text-purple-500" /> Authentication
            </h2>
            <p className="text-zinc-700 dark:text-zinc-300 mb-4 leading-relaxed">
              Authenticate your API requests by including your API key in the Authorization header.
            </p>
            <div className="bg-zinc-900 rounded-xl p-4 overflow-x-auto">
              <pre className="text-sm text-zinc-300 font-mono">
{`Authorization: Bearer YOUR_RUDRA_API_KEY`}
              </pre>
            </div>
          </section>

          {/* Section 3 */}
          <section>
            <h2 className="text-2xl font-bold mb-4 text-zinc-900 dark:text-white flex items-center gap-2">
              <Terminal className="text-emerald-500" /> Endpoints
            </h2>
            
            <div className="space-y-6">
              {/* Endpoint 1 */}
              <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                <div className="bg-zinc-50 dark:bg-zinc-900/50 px-4 py-3 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-3">
                  <span className="bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-400 px-2 py-1 rounded text-xs font-bold uppercase">POST</span>
                  <span className="font-mono text-sm text-zinc-900 dark:text-white">/chat/completions</span>
                </div>
                <div className="p-4">
                  <p className="text-zinc-600 dark:text-zinc-400 text-sm mb-4">Generate conversational AI responses.</p>
                  <div className="bg-zinc-900 rounded-lg p-3 overflow-x-auto">
                    <pre className="text-xs text-zinc-300 font-mono">
{`curl -X POST https://api.rudra-omnitools.com/v1/chat/completions \\
  -H "Authorization: Bearer YOUR_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"prompt": "Hello, world!"}'`}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Endpoint 2 */}
              <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                <div className="bg-zinc-50 dark:bg-zinc-900/50 px-4 py-3 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-3">
                  <span className="bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400 px-2 py-1 rounded text-xs font-bold uppercase">GET</span>
                  <span className="font-mono text-sm text-zinc-900 dark:text-white">/downloader/video</span>
                </div>
                <div className="p-4">
                  <p className="text-zinc-600 dark:text-zinc-400 text-sm mb-4">Extract direct download links from social media URLs.</p>
                  <div className="bg-zinc-900 rounded-lg p-3 overflow-x-auto">
                    <pre className="text-xs text-zinc-300 font-mono">
{`curl -X GET "https://api.rudra-omnitools.com/v1/downloader/video?url=https://tiktok.com/..." \\
  -H "Authorization: Bearer YOUR_KEY"`}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
