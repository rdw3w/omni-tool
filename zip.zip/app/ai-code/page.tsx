'use client';

import { useState } from 'react';
import { Code2, Terminal, Copy, Check } from 'lucide-react';

export default function AICodeGenerator() {
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;
    setGenerating(true);
    setTimeout(() => {
      setResult(`// Generated code for: ${prompt}\n\nfunction executeTask() {\n  console.log("Executing task...");\n  // Implementation details here\n  return true;\n}\n\nexport default executeTask;`);
      setGenerating(false);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Code2 size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">AI Code Assistant</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Generate code snippets from natural language.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={handleGenerate} className="mb-8">
            <div className="flex gap-4">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., Write a Python function to reverse a string"
                className="flex-1 px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white text-lg font-mono"
              />
              <button 
                type="submit"
                disabled={generating || !prompt}
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl font-bold transition-colors flex items-center gap-2"
              >
                {generating ? <Terminal className="animate-spin" /> : <Terminal />}
                Generate
              </button>
            </div>
          </form>

          {result && (
            <div className="relative rounded-xl overflow-hidden bg-[#1e1e1e] border border-zinc-800">
              <div className="flex items-center justify-between px-4 py-2 bg-[#2d2d2d] border-b border-zinc-700">
                <span className="text-xs font-mono text-zinc-400">Generated Code</span>
                <button 
                  onClick={copyToClipboard}
                  className="text-zinc-400 hover:text-white transition-colors flex items-center gap-1 text-xs"
                >
                  {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="p-4 overflow-x-auto text-sm font-mono text-zinc-300">
                <code>{result}</code>
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
