'use client';

import { useState, useEffect } from 'react';
import { useAdmin } from '@/components/AdminProvider';
import { Shield, Power, Lock, KeyRound, CheckCircle2, XCircle, Activity, Users, TrendingUp, MessageSquare } from 'lucide-react';
import { BackButton } from '@/components/BackButton';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const toolNames: Record<string, string> = {
  chat: 'AI Chat',
  videoGen: 'AI Video Generator',
  wpGen: 'WP Post Generator',
  textToSpeech: 'Text to Speech',
  aiImage: 'AI Image Generator',
  aiStory: 'AI Story Generator',
  aiCode: 'AI Code Assistant',
  aiPrompt: 'AI Prompt Builder',
  videoDl: 'Universal Downloader',
  instaDl: 'Instagram Downloader',
  ytDl: 'YouTube Downloader',
  tiktokDl: 'TikTok Downloader',
  twitterDl: 'Twitter Downloader',
  fbDl: 'Facebook Downloader',
  pinterestDl: 'Pinterest Downloader',
  redditDl: 'Reddit Downloader',
  todoList: 'To-Do List',
  notepad: 'Notepad',
  wordCounter: 'Word Counter',
  loremIpsum: 'Lorem Ipsum',
  pomodoro: 'Pomodoro Timer',
  markdown: 'Markdown Editor',
  habitTracker: 'Habit Tracker',
  expenseTracker: 'Expense Tracker',
  qr: 'QR Code Generator',
  passwordGen: 'Password Generator',
  tempMail: 'Temp Mail',
  currencyConverter: 'Currency Converter',
  unitConverter: 'Unit Converter',
  bmiCalculator: 'BMI Calculator',
  ageCalculator: 'Age Calculator',
  stopwatch: 'Stopwatch',
  jsonFormatter: 'JSON Formatter',
  base64: 'Base64 Encoder',
  hashGen: 'Hash Generator',
  colorPicker: 'Color Picker',
  imageCompressor: 'Image Compressor',
  urlShortener: 'URL Shortener',
  jwtDecoder: 'JWT Decoder',
  cssGradient: 'CSS Gradient Generator',
  waifuGen: 'Waifu Generator',
  memeGen: 'Meme Generator',
  githubInfo: 'GitHub Info',
  tgInfo: 'Telegram Info',
};

// Mock data for graphs
const userGrowthData = [
  { name: 'Mon', users: 400 },
  { name: 'Tue', users: 600 },
  { name: 'Wed', users: 850 },
  { name: 'Thu', users: 1200 },
  { name: 'Fri', users: 1800 },
  { name: 'Sat', users: 2400 },
  { name: 'Sun', users: 3100 },
];

const chatUsageData = [
  { time: '00:00', messages: 120 },
  { time: '04:00', messages: 80 },
  { time: '08:00', messages: 450 },
  { time: '12:00', messages: 980 },
  { time: '16:00', messages: 1100 },
  { time: '20:00', messages: 850 },
  { time: '23:59', messages: 300 },
];

export default function AdminPage() {
  const { tools, updateTool, isLoading } = useAdmin();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [userCount, setUserCount] = useState<number>(3100); // Mock starting count

  useEffect(() => {
    if (isAuthenticated) {
      // Simulate real-time user count updates
      const interval = setInterval(() => {
        setUserCount(prev => prev + Math.floor(Math.random() * 5));
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'SHATARUDRA@12') {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Incorrect password. Access denied.');
      setPassword('');
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center bg-zinc-50 dark:bg-zinc-950">
        <div className="animate-pulse flex flex-col items-center">
          <Shield size={48} className="text-zinc-300 dark:text-zinc-700 mb-4" />
          <p className="text-zinc-500 font-medium">Loading secure environment...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 transition-colors duration-300 items-center justify-center">
        <div className="absolute top-6 left-6">
          <BackButton />
        </div>
        <div className="w-full max-w-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl shadow-xl p-8 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 to-orange-500"></div>
          
          <div className="w-20 h-20 bg-red-100 dark:bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
            <Lock size={36} />
          </div>
          
          <h1 className="text-2xl font-bold text-center text-zinc-900 dark:text-white mb-2">Admin Authentication</h1>
          <p className="text-center text-zinc-500 dark:text-zinc-400 mb-8 text-sm">
            Restricted area. Please enter the master password to access the control panel.
          </p>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <KeyRound size={18} className="text-zinc-400" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter master password"
                  className="w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all dark:text-white"
                  autoFocus
                />
              </div>
              {error && <p className="text-red-500 text-sm mt-2 font-medium text-center">{error}</p>}
            </div>
            <button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-xl transition-colors shadow-md hover:shadow-lg flex items-center justify-center gap-2"
            >
              <Shield size={18} />
              Authenticate
            </button>
          </form>
        </div>
      </div>
    );
  }

  const totalTools = Object.keys(tools).length;
  const activeTools = Object.values(tools).filter(Boolean).length;
  const disabledTools = totalTools - activeTools;

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12 transition-colors duration-300">
      <div className="max-w-6xl mx-auto w-full mt-12 md:mt-0">
        <div className="flex items-center justify-between mb-8">
          <BackButton />
          <button 
            onClick={() => setIsAuthenticated(false)}
            className="flex items-center gap-2 px-4 py-2 bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-sm font-medium transition-colors"
          >
            <Lock size={16} /> Lock Panel
          </button>
        </div>
        
        <header className="mb-8 flex flex-col md:flex-row md:items-center gap-6 border-b border-zinc-200 dark:border-zinc-800 pb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-orange-600 text-white rounded-3xl flex items-center justify-center shadow-lg shadow-red-500/20">
            <Shield size={40} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-zinc-900 dark:text-white tracking-tight">Master Control Panel</h1>
            <p className="text-lg text-zinc-500 dark:text-zinc-400 mt-1">Manage platform tools, monitor real-time analytics, and global settings.</p>
          </div>
        </header>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 flex items-center gap-4 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Users size={64} />
            </div>
            <div className="w-12 h-12 bg-purple-100 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-xl flex items-center justify-center relative z-10">
              <Users size={24} />
            </div>
            <div className="relative z-10">
              <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400 flex items-center gap-2">
                Real-Time Users <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              </p>
              <p className="text-3xl font-black text-zinc-900 dark:text-white">
                {userCount.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 flex items-center gap-4 shadow-sm">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center">
              <Activity size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Total Tools</p>
              <p className="text-3xl font-black text-zinc-900 dark:text-white">{totalTools}</p>
            </div>
          </div>
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 flex items-center gap-4 shadow-sm">
            <div className="w-12 h-12 bg-green-100 dark:bg-green-500/10 text-green-600 dark:text-green-400 rounded-xl flex items-center justify-center">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Active Tools</p>
              <p className="text-3xl font-black text-zinc-900 dark:text-white">{activeTools}</p>
            </div>
          </div>
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 flex items-center gap-4 shadow-sm">
            <div className="w-12 h-12 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 rounded-xl flex items-center justify-center">
              <XCircle size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Disabled Tools</p>
              <p className="text-3xl font-black text-zinc-900 dark:text-white">{disabledTools}</p>
            </div>
          </div>
        </div>

        {/* Analytics Graphs */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
          {/* User Growth Chart */}
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-indigo-100 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <TrendingUp size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-white">User Growth (Weekly)</h3>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">New signups and active users</p>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={userGrowthData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#3f3f46" opacity={0.2} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '8px', color: '#fff' }}
                    itemStyle={{ color: '#818cf8' }}
                  />
                  <Area type="monotone" dataKey="users" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorUsers)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chat Usage Chart */}
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-pink-100 dark:bg-pink-500/10 text-pink-600 dark:text-pink-400 flex items-center justify-center">
                <MessageSquare size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-white">AI Chat Usage (Today)</h3>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">Messages processed per hour</p>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chatUsageData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#3f3f46" opacity={0.2} />
                  <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '8px', color: '#fff' }}
                    itemStyle={{ color: '#f472b6' }}
                  />
                  <Line type="monotone" dataKey="messages" stroke="#ec4899" strokeWidth={3} dot={{ r: 4, fill: '#ec4899', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Tool Management */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-zinc-900 dark:text-white">Tool Management</h2>
            <span className="px-3 py-1 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs font-bold rounded-full uppercase tracking-wider">Live Sync</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(tools).map(([toolId, isEnabled]) => {
              // Skip image tool if it exists in state
              if (toolId === 'image') return null;
              
              return (
                <div 
                  key={toolId} 
                  className={`flex items-center justify-between p-4 border rounded-2xl transition-all ${
                    isEnabled 
                      ? 'bg-zinc-50 dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800' 
                      : 'bg-red-50/50 dark:bg-red-950/20 border-red-100 dark:border-red-900/30'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                      isEnabled ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400'
                    }`}>
                      <Power size={18} />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-zinc-900 dark:text-white text-base truncate">{toolNames[toolId] || toolId}</h3>
                      <p className={`text-xs ${isEnabled ? 'text-zinc-500 dark:text-zinc-400' : 'text-red-500 dark:text-red-400'}`}>
                        {isEnabled ? 'Active' : 'Disabled'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => updateTool(toolId, !isEnabled)}
                    className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-zinc-900 ${
                      isEnabled ? 'bg-green-500' : 'bg-zinc-300 dark:bg-zinc-700'
                    }`}
                  >
                    <span className="sr-only">Toggle {toolNames[toolId]}</span>
                    <span
                      className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform shadow-sm ${
                        isEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
