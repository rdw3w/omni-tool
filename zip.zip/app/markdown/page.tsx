'use client';

import { useState } from 'react';
import { FileCode2, Eye } from 'lucide-react';

export default function MarkdownPreviewer() {
  const [markdown, setMarkdown] = useState('# Hello Markdown\n\nWrite your markdown here and see the preview instantly.\n\n## Features\n- **Bold text**\n- *Italic text*\n- [Links](https://example.com)\n\n```javascript\nconsole.log("Code blocks work too!");\n```');
  const [view, setView] = useState<'split' | 'edit' | 'preview'>('split');

  return (
    <div className="flex flex-col h-full bg-zinc-50 dark:bg-zinc-950">
      <header className="p-6 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-white dark:bg-zinc-900">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-500/10 text-blue-600 rounded-xl flex items-center justify-center">
            <FileCode2 size={20} />
          </div>
          <h1 className="text-xl font-bold text-zinc-900 dark:text-white">Markdown Editor</h1>
        </div>
        <div className="flex bg-zinc-100 dark:bg-zinc-800 rounded-lg p-1">
          <button onClick={() => setView('edit')} className={`px-4 py-1.5 rounded-md text-sm font-medium ${view === 'edit' ? 'bg-white dark:bg-zinc-700 shadow-sm' : 'text-zinc-500'}`}>Edit</button>
          <button onClick={() => setView('split')} className={`px-4 py-1.5 rounded-md text-sm font-medium hidden md:block ${view === 'split' ? 'bg-white dark:bg-zinc-700 shadow-sm' : 'text-zinc-500'}`}>Split</button>
          <button onClick={() => setView('preview')} className={`px-4 py-1.5 rounded-md text-sm font-medium ${view === 'preview' ? 'bg-white dark:bg-zinc-700 shadow-sm' : 'text-zinc-500'}`}>Preview</button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {(view === 'split' || view === 'edit') && (
          <div className={`flex-1 border-r border-zinc-200 dark:border-zinc-800 ${view === 'edit' ? 'w-full' : 'hidden md:block'}`}>
            <textarea
              value={markdown}
              onChange={(e) => setMarkdown(e.target.value)}
              className="w-full h-full p-6 bg-transparent resize-none focus:outline-none text-zinc-800 dark:text-zinc-200 font-mono text-sm"
              placeholder="Type markdown here..."
            />
          </div>
        )}
        
        {(view === 'split' || view === 'preview') && (
          <div className={`flex-1 p-6 overflow-y-auto bg-white dark:bg-zinc-950 ${view === 'preview' ? 'w-full' : 'hidden md:block'}`}>
            <div className="prose dark:prose-invert max-w-none">
              {/* Simple mock preview since we don't have react-markdown installed in this snippet */}
              <div dangerouslySetInnerHTML={{ 
                __html: markdown
                  .replace(/^# (.*$)/gim, '<h1>$1</h1>')
                  .replace(/^## (.*$)/gim, '<h2>$1</h2>')
                  .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
                  .replace(/\*(.*)\*/gim, '<em>$1</em>')
                  .replace(/\[(.*?)\]\((.*?)\)/gim, '<a href="$2" class="text-blue-500 underline">$1</a>')
                  .replace(/\n/gim, '<br />')
              }} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
