const url = `https://t.me/durov`;
fetch(url, {
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  }
}).then(res => res.text()).then(html => {
    const getMeta = (property) => {
        const regex = new RegExp(`<meta(?:\\s+[^>]*?)?(?:property|name)=["']${property}["'](?:\\s+[^>]*?)?content=["']([^"']*)["']`, 'i');
        const match = html.match(regex);
        if (match) return match[1];

        const regexAlt = new RegExp(`<meta(?:\\s+[^>]*?)?content=["']([^"']*)["'](?:\\s+[^>]*?)?(?:property|name)=["']${property}["']`, 'i');
        const matchAlt = html.match(regexAlt);
        if (matchAlt) return matchAlt[1];

        return null;
    };
    console.log("Title: ", getMeta('og:title'));
    console.log("Desc: ", getMeta('og:description'));
});
