// test-tg.js
const url = "https://t.me/durov";
fetch(url, {
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5'
  }
})
.then(res => {
  console.log("Status:", res.status);
  return res.text();
})
.then(html => {
  const getMeta = (property) => {
    const regex = new RegExp(`<meta(?:\\s+[^>]*?)?(?:property|name)=["']${property}["'](?:\\s+[^>]*?)?content=["']([^"']*)["']`, 'i');
    const match = html.match(regex);
    if (match) return match[1];

    const regexAlt = new RegExp(`<meta(?:\\s+[^>]*?)?content=["']([^"']*)["'](?:\\s+[^>]*?)?(?:property|name)=["']${property}["']`, 'i');
    const matchAlt = html.match(regexAlt);
    if (matchAlt) return matchAlt[1];

    return null;
  };
  
  const title = getMeta('og:title');
  console.log("Title: " + title);
  console.log("Error logic title test:", (!title || title === 'Telegram'));
  
})
.catch(err => console.error(err));
