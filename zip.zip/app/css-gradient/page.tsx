'use client';

import { useState } from 'react';
import { Palette, Copy, Check } from 'lucide-react';

export default function CSSGradientGenerator() {
  const [color1, setColor1] = useState('#4f46e5');
  const [color2, setColor2] = useState('#ec4899');
  const [angle, setAngle] = useState(135);
  const [copied, setCopied] = useState(false);

  const gradient = `linear-gradient(${angle}deg, ${color1}, ${color2})`;
  const cssCode = `background: ${gradient};`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(cssCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-pink-500 text-white rounded-2xl flex items-center justify-center shadow-sm">
            <Palette size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">CSS Gradient Generator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Create beautiful CSS gradients easily.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div 
            className="w-full h-48 md:h-64 rounded-2xl mb-8 shadow-inner transition-all duration-300"
            style={{ background: gradient }}
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Color 1</label>
              <div className="flex items-center gap-3">
                <input type="color" value={color1} onChange={(e) => setColor1(e.target.value)} className="w-12 h-12 rounded cursor-pointer bg-transparent border-0 p-0" />
                <input type="text" value={color1} onChange={(e) => setColor1(e.target.value)} className="flex-1 px-3 py-2 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg focus:outline-none dark:text-white font-mono uppercase" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Color 2</label>
              <div className="flex items-center gap-3">
                <input type="color" value={color2} onChange={(e) => setColor2(e.target.value)} className="w-12 h-12 rounded cursor-pointer bg-transparent border-0 p-0" />
                <input type="text" value={color2} onChange={(e) => setColor2(e.target.value)} className="flex-1 px-3 py-2 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg focus:outline-none dark:text-white font-mono uppercase" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Angle: {angle}°</label>
              <input 
                type="range" 
                min="0" max="360" 
                value={angle} 
                onChange={(e) => setAngle(Number(e.target.value))}
                className="w-full h-2 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer mt-4"
              />
            </div>
          </div>

          <div className="relative bg-zinc-900 rounded-xl p-4 flex items-center justify-between border border-zinc-800">
            <code className="text-zinc-300 font-mono text-sm">{cssCode}</code>
            <button 
              onClick={copyToClipboard}
              className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-zinc-300 transition-colors"
            >
              {copied ? <Check size={18} className="text-green-400" /> : <Copy size={18} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
