'use client';

import { useState } from 'react';
import { Send, Bot, User, RefreshCw, MessageSquare } from 'lucide-react';

export default function ChatPage() {
  const [messages, setMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([
    { role: 'assistant', content: 'Hello! I am ready to help you. What would you like to know?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      // Connecting to the W@rm GPT API
      const response = await fetch(`https://tobi-warm-api.vercel.app/ask?apikey=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&model=llama-3.1-8b-instant&routerurl=https://api.groq.com/openai/v1/chat/completions&q=${encodeURIComponent(userMessage)}`);
      
      const data = await response.text();
      // The API often returns plain text or a JSON with "response" or "answer"
      let botAnswer = data;
      try {
        const json = JSON.parse(data);
        botAnswer = json.response || json.answer || json.reply || data;
      } catch (err) {}

      setMessages(prev => [...prev, { role: 'assistant', content: botAnswer }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12 relative">
      <div className="max-w-4xl mx-auto w-full h-full flex flex-col relative z-10">
        <header className="mb-8 flex items-center gap-4 shrink-0">
          <div className="w-16 h-16 bg-blue-100 dark:bg-blue-500/10 text-blue-500 rounded-2xl flex items-center justify-center shadow-sm">
            <MessageSquare size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-500">🤖 W@rm GPT Chat</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Fast, intelligent, and colorful conversational AI.</p>
          </div>
        </header>

        <div className="flex-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 shadow-xl flex flex-col min-h-0">
          <div className="flex-1 overflow-y-auto space-y-6 pr-4 mb-6 custom-scrollbar">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  msg.role === 'user' ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400' : 'bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-md'
                }`}>
                  {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
                </div>
                <div className={`px-6 py-4 rounded-2xl max-w-[80%] text-sm leading-relaxed shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 rounded-tr-sm' 
                    : 'bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 text-zinc-800 dark:text-zinc-200 rounded-tl-sm'
                }`}>
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-md flex items-center justify-center shrink-0">
                  <RefreshCw className="animate-spin" size={18} />
                </div>
                <div className="px-6 py-4 rounded-2xl bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 text-zinc-500 rounded-tl-sm flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={sendMessage} className="relative shrink-0">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything..."
              disabled={loading}
              className="w-full pl-6 pr-16 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white shadow-inner transition-all text-lg"
            />
            <button 
              type="submit"
              disabled={loading || !input.trim()}
              className="absolute right-2 top-2 bottom-2 aspect-square bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl flex items-center justify-center disabled:opacity-50 hover:scale-105 active:scale-95 transition-all shadow-md shadow-blue-500/30"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
        
        <div className="mt-8 text-center shrink-0">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
