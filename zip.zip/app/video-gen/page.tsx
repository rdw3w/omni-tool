'use client';

import { useState } from 'react';
import { Video, RefreshCw, Download, PlayCircle } from 'lucide-react';

export default function AIVideoGenerator() {
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;
    setGenerating(true);
    
    // Direct API usage to fetch generated video
    const apiUrl = `https://tobi-aigen-api.vercel.app/gen?vid=${encodeURIComponent(prompt)}&t=${Date.now()}`;
    setVideoUrl(apiUrl);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-pink-100 dark:bg-pink-500/10 text-pink-600 rounded-2xl flex items-center justify-center shadow-sm">
            <Video size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-rose-500">🎬 AI Video Generator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Create short videos from text prompts instantly.</p>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl">
            <h2 className="text-xl font-bold mb-6 text-zinc-900 dark:text-white flex items-center gap-2">
              <PlayCircle className="text-pink-500" /> Action!
            </h2>
            <form onSubmit={handleGenerate} className="flex flex-col gap-6">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A cat playing a piano in space..."
                className="w-full h-40 px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 dark:text-white transition-all text-sm leading-relaxed resize-none"
                required
              />
              <button 
                type="submit"
                disabled={generating || !prompt}
                className="w-full py-4 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-pink-500/25 flex items-center justify-center gap-2"
              >
                {generating ? <RefreshCw className="animate-spin" /> : <Video />}
                {generating ? 'Processing Frames...' : 'Generate Video'}
              </button>
            </form>
          </div>

          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl flex flex-col">
            <h2 className="text-xl font-bold mb-6 text-zinc-900 dark:text-white flex items-center gap-2">
              <Video className="text-pink-500" /> Result
            </h2>
            <div className="flex-1 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl flex items-center justify-center relative overflow-hidden group shadow-inner min-h-[300px]">
              {!videoUrl ? (
                <div className="text-center p-6 opacity-60">
                  <Video size={48} className="mx-auto text-zinc-400 mb-3" />
                  <p className="text-zinc-500 text-sm font-medium">Your generated video will play here</p>
                </div>
              ) : (
                <>
                  {generating && (
                    <div className="absolute inset-0 z-10 bg-white/60 dark:bg-black/60 backdrop-blur-md flex flex-col items-center justify-center">
                      <RefreshCw size={40} className="animate-spin text-pink-500 mb-4" />
                      <p className="font-bold text-zinc-800 dark:text-zinc-200 animate-pulse">Rendering video...</p>
                    </div>
                  )}
                  {/* Depending on API behavior, it might return a GIF or an MP4. We will use video tag with autoPlay and fallback to img if needed. We assume it might be a direct playable stream. */}
                  <video 
                    src={videoUrl} 
                    controls
                    autoPlay
                    loop
                    className="w-full h-full object-cover"
                    onLoadedData={() => setGenerating(false)}
                    onError={(e) => {
                       // Fallback in case the API actually returns an image/gif despite being a video API
                       setGenerating(false);
                    }}
                  />
                  <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                    <a href={videoUrl} target="_blank" download="generated-video.mp4" className="w-12 h-12 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-sm shadow-xl rounded-full flex items-center justify-center text-zinc-900 dark:text-white hover:scale-110 transition-transform">
                      <Download size={20} className="text-pink-500" />
                    </a>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-16 text-center pb-8 border-t border-zinc-200 dark:border-zinc-800 pt-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
