'use client';

import { useState } from 'react';
import { Download, Loader2, Link as LinkIcon, ExternalLink } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function VideoDownloaderPage() {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`/api/video-dl?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to fetch download link');
      }

      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to process the URL. Please ensure it is a valid video link.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        <header className="mb-8 text-center">
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Download size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-2">Universal Video Downloader</h1>
          <p className="text-zinc-400">Download videos from YouTube, Facebook, TikTok, and more.</p>
        </header>

        <form onSubmit={handleDownload} className="mb-12">
          <div className="relative flex items-center">
            <div className="absolute left-4 text-zinc-500">
              <LinkIcon size={20} />
            </div>
            <input
              type="url"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste video URL here..."
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl pl-12 pr-32 py-4 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!url.trim() || isLoading}
              className="absolute right-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
              Get Link
            </button>
          </div>
          {error && <p className="text-red-400 text-sm mt-3 text-center">{error}</p>}
        </form>

        {isLoading && (
          <div className="flex justify-center py-12">
            <Loader2 size={48} className="animate-spin text-emerald-500" />
          </div>
        )}

        {result && (
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-xl font-semibold mb-4">Download Ready</h3>
            
            {/* The API response structure might vary, so we handle a generic display */}
            <div className="space-y-4">
              {result.title && (
                <p className="text-zinc-300 font-medium">{result.title}</p>
              )}
              
              {result.thumbnail && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={result.thumbnail} alt="Thumbnail" className="w-full max-w-sm rounded-lg object-cover" />
              )}

              <div className="flex flex-wrap gap-3 mt-6">
                {/* Try to find download links in the response */}
                {result.url ? (
                  <a 
                    href={result.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium flex items-center gap-2 transition-colors"
                  >
                    <Download size={18} />
                    Download Video
                  </a>
                ) : result.links ? (
                  Array.isArray(result.links) ? result.links.map((link: any, idx: number) => (
                    <a 
                      key={idx}
                      href={link.url || link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-medium flex items-center gap-2 transition-colors"
                    >
                      <ExternalLink size={18} />
                      {link.quality || link.type || `Download Option ${idx + 1}`}
                    </a>
                  )) : null
                ) : (
                  <div className="w-full overflow-x-auto bg-black/50 p-4 rounded-lg">
                    <pre className="text-xs text-zinc-400">{JSON.stringify(result, null, 2)}</pre>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
