'use client';

import { Check, Zap, Shield, Crown, MessageCircle } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function PricingPage() {
  return (
    <div className="flex flex-col h-full overflow-y-auto bg-white dark:bg-zinc-950 p-6 md:p-12 transition-colors duration-300">
      <div className="max-w-6xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        
        <header className="mb-16 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 text-zinc-900 dark:text-white">Simple, Transparent Pricing</h1>
          <p className="text-xl text-zinc-600 dark:text-zinc-400 max-w-2xl mx-auto">
            Choose the perfect plan for your needs. Get access to the powerful Rudra API.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Free Plan */}
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 flex flex-col">
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">Free</h3>
            <p className="text-zinc-500 dark:text-zinc-400 mb-6">Perfect for testing and personal use.</p>
            <div className="mb-6">
              <span className="text-4xl font-extrabold text-zinc-900 dark:text-white">$0</span>
              <span className="text-zinc-500 dark:text-zinc-400">/month</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['100 API calls/day', 'Standard support', 'Basic tools access', 'Community forum'].map((feature) => (
                <li key={feature} className="flex items-center gap-3 text-zinc-700 dark:text-zinc-300">
                  <Check size={20} className="text-emerald-500 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button className="w-full py-3 px-6 bg-zinc-200 dark:bg-zinc-800 hover:bg-zinc-300 dark:hover:bg-zinc-700 text-zinc-900 dark:text-white rounded-xl font-medium transition-colors">
              Get Started
            </button>
          </div>

          {/* Pro Plan */}
          <div className="bg-gradient-to-b from-blue-600 to-purple-600 rounded-3xl p-8 flex flex-col relative transform md:-translate-y-4 shadow-2xl">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-xs font-bold uppercase tracking-wider py-1 px-3 rounded-full">
              Most Popular
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Pro</h3>
            <p className="text-blue-100 mb-6">For professionals and small teams.</p>
            <div className="mb-6">
              <span className="text-4xl font-extrabold text-white">$49</span>
              <span className="text-blue-200">/month</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['10,000 API calls/day', 'Priority email support', 'All tools access', 'Faster generation times', 'No watermarks'].map((feature) => (
                <li key={feature} className="flex items-center gap-3 text-white">
                  <Check size={20} className="text-blue-200 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button className="w-full py-3 px-6 bg-white text-blue-600 hover:bg-zinc-100 rounded-xl font-bold transition-colors shadow-lg">
              Upgrade to Pro
            </button>
          </div>

          {/* Enterprise Plan */}
          <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 flex flex-col">
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">Enterprise Token</h3>
            <p className="text-zinc-500 dark:text-zinc-400 mb-6">Unlimited power for large scale apps.</p>
            <div className="mb-6">
              <span className="text-4xl font-extrabold text-zinc-900 dark:text-white">$1000</span>
              <span className="text-zinc-500 dark:text-zinc-400">/lifetime</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['Unlimited API calls', '24/7 dedicated support', 'Custom integrations', 'SLA guarantee', 'Dedicated account manager'].map((feature) => (
                <li key={feature} className="flex items-center gap-3 text-zinc-700 dark:text-zinc-300">
                  <Check size={20} className="text-emerald-500 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <a 
              href="https://t.me/Sunsuin662" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full py-3 px-6 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 rounded-xl font-medium transition-colors text-center flex items-center justify-center gap-2"
            >
              <MessageCircle size={18} />
              Buy Token
            </a>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-2xl border border-blue-100 dark:border-blue-800/30">
            <MessageCircle size={20} />
            <span className="font-medium">Have questions or need a custom plan? Contact me on Telegram: <strong>@Sunsuin662</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
}
