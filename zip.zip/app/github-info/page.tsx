'use client';

import { useState } from 'react';
import { Github, Search, Book, Users, Star, GitFork, ExternalLink } from 'lucide-react';

export default function GitHubInfo() {
  const [username, setUsername] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`https://api.github.com/users/${encodeURIComponent(username)}`);
      if (!res.ok) throw new Error('User not found');
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch user info');
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-zinc-200 dark:bg-zinc-800 text-zinc-900 dark:text-white rounded-2xl flex items-center justify-center shadow-sm">
            <Github size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-zinc-700 to-zinc-900 dark:from-zinc-100 dark:to-zinc-400">🐙 GitHub Info</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Get complete details about any GitHub user.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl mb-8">
          <form onSubmit={fetchInfo} className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="text-zinc-400" size={20} />
              </div>
              <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter GitHub username (e.g. torvalds)"
                className="w-full pl-12 pr-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-500 dark:text-white font-medium text-lg"
              />
            </div>
            <button 
              type="submit"
              disabled={loading || !username.trim()}
              className="px-8 py-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-900 rounded-xl font-bold transition-all disabled:opacity-50 flex items-center justify-center shadow-lg"
            >
              {loading ? 'Searching...' : 'Search User'}
            </button>
          </form>
          {error && <p className="text-red-500 mt-4 font-medium px-2">{error}</p>}
        </div>

        {data && (
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl overflow-hidden relative">
            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
              <Github size={120} />
            </div>
            
            <div className="flex flex-col md:flex-row gap-8 relative z-10">
              <img src={data.avatar_url} alt={data.login} className="w-32 h-32 md:w-48 md:h-48 rounded-full border-4 border-zinc-100 dark:border-zinc-800 shadow-lg object-cover" />
              
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-3xl font-black text-zinc-900 dark:text-white">{data.name || data.login}</h2>
                  <a href={data.html_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-blue-500 hover:text-blue-600 font-bold bg-blue-50 dark:bg-blue-500/10 px-4 py-2 rounded-lg transition-colors">
                    View Profile <ExternalLink size={16} />
                  </a>
                </div>
                <p className="text-zinc-500 dark:text-zinc-400 font-mono mb-4">@{data.login}</p>
                {data.bio && <p className="text-zinc-700 dark:text-zinc-300 text-lg mb-6 leading-relaxed">{data.bio}</p>}
                
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
                  <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col gap-1 items-center justify-center shadow-sm">
                    <Users size={20} className="text-blue-500 mb-1" />
                    <span className="text-2xl font-black text-zinc-900 dark:text-white">{data.followers}</span>
                    <span className="text-xs font-bold text-zinc-500 uppercase">Followers</span>
                  </div>
                  <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col gap-1 items-center justify-center shadow-sm">
                    <Users size={20} className="text-purple-500 mb-1" />
                    <span className="text-2xl font-black text-zinc-900 dark:text-white">{data.following}</span>
                    <span className="text-xs font-bold text-zinc-500 uppercase">Following</span>
                  </div>
                  <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col gap-1 items-center justify-center shadow-sm">
                    <Book size={20} className="text-emerald-500 mb-1" />
                    <span className="text-2xl font-black text-zinc-900 dark:text-white">{data.public_repos}</span>
                    <span className="text-xs font-bold text-zinc-500 uppercase">Repositories</span>
                  </div>
                  <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 flex flex-col gap-1 items-center justify-center shadow-sm">
                    <GitFork size={20} className="text-orange-500 mb-1" />
                    <span className="text-2xl font-black text-zinc-900 dark:text-white">{data.public_gists}</span>
                    <span className="text-xs font-bold text-zinc-500 uppercase">Gists</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="mt-12 text-center pb-8 border-t border-zinc-200 dark:border-zinc-800 pt-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
