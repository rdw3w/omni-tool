'use client';

import { useState } from 'react';
import { Scale, ArrowRightLeft } from 'lucide-react';

export default function UnitConverter() {
  const [amount, setAmount] = useState('1');
  const [from, setFrom] = useState('meters');
  const [to, setTo] = useState('feet');

  // Simple length conversion for demo
  const rates: Record<string, number> = {
    meters: 1,
    feet: 3.28084,
    inches: 39.3701,
    centimeters: 100,
    kilometers: 0.001,
    miles: 0.000621371,
  };

  const convert = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount)) return '0.00';
    const result = (numAmount / rates[from]) * rates[to];
    return result.toFixed(4);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-violet-100 dark:bg-violet-500/10 text-violet-600 dark:text-violet-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Scale size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Unit Converter</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Convert between different units of measurement.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-1 w-full">
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Value</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-violet-500 dark:text-white text-lg"
              />
            </div>
            
            <div className="flex-1 w-full flex items-end gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">From</label>
                <select
                  value={from}
                  onChange={(e) => setFrom(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-violet-500 dark:text-white text-lg capitalize"
                >
                  {Object.keys(rates).map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>
              
              <button 
                onClick={() => { setFrom(to); setTo(from); }}
                className="mb-1 p-3 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
              >
                <ArrowRightLeft size={20} />
              </button>

              <div className="flex-1">
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">To</label>
                <select
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-violet-500 dark:text-white text-lg capitalize"
                >
                  {Object.keys(rates).map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="mt-10 p-8 bg-violet-50 dark:bg-violet-500/5 border border-violet-100 dark:border-violet-500/10 rounded-2xl text-center">
            <p className="text-zinc-500 dark:text-zinc-400 text-lg mb-2">{amount || '0'} {from} equals</p>
            <p className="text-5xl font-black text-violet-600 dark:text-violet-400">{convert()} {to}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
