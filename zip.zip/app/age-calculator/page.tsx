'use client';

import { useState } from 'react';
import { Calendar } from 'lucide-react';

export default function AgeCalculator() {
  const [dob, setDob] = useState('');
  const [age, setAge] = useState<{ years: number; months: number; days: number } | null>(null);

  const calculateAge = () => {
    if (!dob) return;
    
    const birthDate = new Date(dob);
    const today = new Date();
    
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();

    if (days < 0) {
      months--;
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }

    setAge({ years, months, days });
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-2xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center shadow-sm">
            <Calendar size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Age Calculator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Calculate your exact age in years, months, and days.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Date of Birth</label>
              <input
                type="date"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white text-lg"
              />
            </div>
            
            <button 
              onClick={calculateAge}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors"
            >
              Calculate Age
            </button>
          </div>

          {age && (
            <div className="mt-10 grid grid-cols-3 gap-4">
              <div className="p-6 bg-blue-50 dark:bg-blue-500/5 border border-blue-100 dark:border-blue-500/10 rounded-2xl text-center">
                <p className="text-4xl font-black text-blue-600 dark:text-blue-400 mb-1">{age.years}</p>
                <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Years</p>
              </div>
              <div className="p-6 bg-blue-50 dark:bg-blue-500/5 border border-blue-100 dark:border-blue-500/10 rounded-2xl text-center">
                <p className="text-4xl font-black text-blue-600 dark:text-blue-400 mb-1">{age.months}</p>
                <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Months</p>
              </div>
              <div className="p-6 bg-blue-50 dark:bg-blue-500/5 border border-blue-100 dark:border-blue-500/10 rounded-2xl text-center">
                <p className="text-4xl font-black text-blue-600 dark:text-blue-400 mb-1">{age.days}</p>
                <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Days</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
