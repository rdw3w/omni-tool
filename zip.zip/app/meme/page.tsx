'use client';

import { useState } from 'react';
import { Smile, RefreshCw, Layers } from 'lucide-react';

export default function MemeGenerator() {
  const [type, setType] = useState<'meme' | 'anime'>('meme');
  const [imageUrl, setImageUrl] = useState('https://meme-api-pi.vercel.app/meme');
  const [loading, setLoading] = useState(false);

  const generateNew = (selectedType: 'meme' | 'anime') => {
    setLoading(true);
    setType(selectedType);
    setImageUrl(`https://meme-api-pi.vercel.app/${selectedType}?t=${Date.now()}`);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-yellow-100 dark:bg-yellow-500/10 text-yellow-500 rounded-2xl flex items-center justify-center shadow-sm">
            <Smile size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 to-amber-500">😂 Meme Generator</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1 font-medium">Get endless random memes and anime memes.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-xl flex flex-col items-center">
          
          <div className="flex bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl mb-8 w-full max-w-md">
            <button 
              onClick={() => generateNew('meme')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${type === 'meme' ? 'bg-white dark:bg-zinc-700 text-yellow-500 shadow-sm' : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
            >
              Regular Memes
            </button>
            <button 
              onClick={() => generateNew('anime')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${type === 'anime' ? 'bg-white dark:bg-zinc-700 text-amber-500 shadow-sm' : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'}`}
            >
              Anime Memes
            </button>
          </div>

          <div className="relative w-full max-w-md aspect-square rounded-2xl overflow-hidden bg-zinc-100 dark:bg-zinc-800 shadow-inner mb-8 flex items-center justify-center border-4 border-yellow-100 dark:border-yellow-900/30">
            {loading && <div className="absolute inset-0 flex items-center justify-center bg-white/50 dark:bg-black/50 backdrop-blur-sm z-10"><RefreshCw className="animate-spin text-yellow-500" size={40} /></div>}
            <img 
              src={imageUrl} 
              alt="Random Meme" 
              className="object-contain w-full h-full"
              onLoad={() => setLoading(false)}
              onError={() => setLoading(false)}
            />
          </div>

          <button 
            onClick={() => generateNew(type)}
            disabled={loading}
            className="w-full max-w-md py-4 bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 disabled:opacity-50 text-white rounded-xl font-bold transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center gap-3 shadow-lg shadow-yellow-500/25"
          >
            {loading ? <RefreshCw className="animate-spin" /> : <Layers />}
            {loading ? 'Finding meme...' : 'Next Meme'}
          </button>
        </div>
        
        <div className="mt-12 text-center pb-8">
          <p className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-1">Developed By</p>
          <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 drop-shadow-sm">Shatarudra</p>
        </div>
      </div>
    </div>
  );
}
