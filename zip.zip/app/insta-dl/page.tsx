'use client';

import { useState } from 'react';
import { Instagram, Loader2, Link as LinkIcon, ExternalLink, Info } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

export default function InstaDownloaderPage() {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`/api/insta-dl?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to fetch download link');
      }

      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to process the URL. Please ensure it is a valid Instagram link.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0">
        <BackButton />
        <header className="mb-8 text-center">
          <div className="w-16 h-16 bg-orange-500/10 text-orange-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Instagram size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-2">Instagram Downloader</h1>
          <p className="text-zinc-400">Download Instagram Reels, Posts, and IGTV videos.</p>
        </header>

        <div className="bg-orange-500/10 border border-orange-500/20 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Info className="text-orange-500 shrink-0 mt-1" size={20} />
          <div className="text-sm text-orange-200">
            <p className="font-bold mb-1">Tool Features & Limitations:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Supports public Instagram Reels, Photo Posts, and Carousels.</li>
              <li>Cannot download content from strictly private accounts or stories without public sharing enabled.</li>
              <li>HD quality media is provided completely watermark-free.</li>
            </ul>
          </div>
        </div>

        <form onSubmit={handleDownload} className="mb-12">
          <div className="relative flex items-center">
            <div className="absolute left-4 text-zinc-500">
              <LinkIcon size={20} />
            </div>
            <input
              type="url"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste Instagram URL here..."
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl pl-12 pr-32 py-4 text-sm focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-all"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!url.trim() || isLoading}
              className="absolute right-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
            >
              {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Instagram size={16} />}
              Get Link
            </button>
          </div>
          {error && <p className="text-red-400 text-sm mt-3 text-center">{error}</p>}
        </form>

        {isLoading && (
          <div className="flex justify-center py-12">
            <Loader2 size={48} className="animate-spin text-orange-500" />
          </div>
        )}

        {result && (
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-xl font-semibold mb-4">Download Ready</h3>
            
            <div className="space-y-4">
              <div className="flex flex-wrap gap-3 mt-6">
                {result.url ? (
                  <a 
                    href={result.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white rounded-xl font-medium flex items-center gap-2 transition-all"
                  >
                    <ExternalLink size={18} />
                    Download Media
                  </a>
                ) : result.picker ? (
                   Array.isArray(result.picker) ? result.picker.map((item: any, idx: number) => (
                    <a 
                      key={idx}
                      href={item.url || item} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-medium flex items-center gap-2 transition-colors border border-zinc-700"
                    >
                      <ExternalLink size={18} />
                      Download Item {idx + 1}
                    </a>
                  )) : null
                ) : result.media ? (
                   Array.isArray(result.media) ? result.media.map((item: any, idx: number) => (
                    <a 
                      key={idx}
                      href={item.url || item} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-medium flex items-center gap-2 transition-colors border border-zinc-700"
                    >
                      <ExternalLink size={18} />
                      Download Part {idx + 1}
                    </a>
                  )) : (
                    <a 
                      href={result.media} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white rounded-xl font-medium flex items-center gap-2 transition-all"
                    >
                      <ExternalLink size={18} />
                      Download Media
                    </a>
                  )
                ) : (
                  <div className="w-full overflow-x-auto bg-black/50 p-4 rounded-lg">
                    <pre className="text-xs text-zinc-400">{JSON.stringify(result, null, 2)}</pre>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
