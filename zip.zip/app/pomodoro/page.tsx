'use client';

import { useState, useEffect } from 'react';
import { Timer, Play, Pause, RotateCcw } from 'lucide-react';

export default function PomodoroTimer() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      alert(mode === 'work' ? 'Work session complete! Take a break.' : 'Break is over! Back to work.');
      if (mode === 'work') {
        setMode('break');
        setTimeLeft(5 * 60);
      } else {
        setMode('work');
        setTimeLeft(25 * 60);
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, mode]);

  const toggleTimer = () => setIsRunning(!isRunning);
  
  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(mode === 'work' ? 25 * 60 : 5 * 60);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-2xl mx-auto w-full mt-12 md:mt-0 text-center">
        <header className="mb-10 flex flex-col items-center gap-4">
          <div className="w-20 h-20 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center shadow-sm">
            <Timer size={40} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">Pomodoro Timer</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Boost your productivity with timed focus sessions.</p>
          </div>
        </header>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-12 shadow-sm">
          <div className="flex justify-center gap-4 mb-8">
            <button 
              onClick={() => { setMode('work'); setTimeLeft(25 * 60); setIsRunning(false); }}
              className={`px-6 py-2 rounded-full font-bold transition-colors ${mode === 'work' ? 'bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400' : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
            >
              Work (25m)
            </button>
            <button 
              onClick={() => { setMode('break'); setTimeLeft(5 * 60); setIsRunning(false); }}
              className={`px-6 py-2 rounded-full font-bold transition-colors ${mode === 'break' ? 'bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400' : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
            >
              Break (5m)
            </button>
          </div>

          <div className="text-8xl md:text-9xl font-black text-zinc-900 dark:text-white mb-12 tracking-tighter">
            {formatTime(timeLeft)}
          </div>

          <div className="flex justify-center gap-6">
            <button 
              onClick={toggleTimer}
              className="w-20 h-20 rounded-full bg-zinc-900 dark:bg-white text-white dark:text-black flex items-center justify-center hover:scale-105 transition-transform shadow-lg"
            >
              {isRunning ? <Pause size={32} /> : <Play size={32} className="ml-2" />}
            </button>
            <button 
              onClick={resetTimer}
              className="w-20 h-20 rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center justify-center hover:scale-105 transition-transform"
            >
              <RotateCcw size={32} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
