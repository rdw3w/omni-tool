import type {Metadata} from 'next';
import './globals.css';
import { Sidebar } from '@/components/Sidebar';
import { ThemeProvider } from '@/components/ThemeProvider';
import { AdminProvider } from '@/components/AdminProvider';
import { AntiInspect } from '@/components/AntiInspect';
import { Background3D } from '@/components/Background3D';

export const metadata: Metadata = {
  title: 'OmniTools AI & Downloader Hub',
  description: 'All-in-One AI Tools & Downloader Platform',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-transparent text-zinc-900 dark:text-zinc-50 min-h-screen flex antialiased transition-colors duration-300" suppressHydrationWarning>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          <AdminProvider>
            <AntiInspect />
            <Background3D />
            <Sidebar />
            <main className="flex-1 flex flex-col h-screen overflow-hidden relative z-10 w-full backdrop-blur-sm bg-white/40 dark:bg-black/40">
              {children}
            </main>
          </AdminProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
