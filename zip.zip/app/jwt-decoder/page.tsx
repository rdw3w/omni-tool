'use client';

import { useState } from 'react';
import { Code, Unlock } from 'lucide-react';

export default function JWTDecoder() {
  const [token, setToken] = useState('');
  const [decoded, setDecoded] = useState<any>(null);
  const [error, setError] = useState('');

  const decodeToken = (t: string) => {
    setToken(t);
    setError('');
    if (!t) {
      setDecoded(null);
      return;
    }
    try {
      const parts = t.split('.');
      if (parts.length !== 3) throw new Error('Invalid JWT format');
      const payload = JSON.parse(atob(parts[1]));
      const header = JSON.parse(atob(parts[0]));
      setDecoded({ header, payload });
    } catch (err) {
      setError('Invalid JWT token');
      setDecoded(null);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-4xl mx-auto w-full mt-12 md:mt-0">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-pink-100 dark:bg-pink-500/10 text-pink-600 rounded-2xl flex items-center justify-center shadow-sm">
            <Unlock size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">JWT Decoder</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Decode JSON Web Tokens instantly.</p>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 shadow-sm">
            <h2 className="font-bold text-lg mb-4 text-zinc-800 dark:text-zinc-200">Encoded Token</h2>
            <textarea
              value={token}
              onChange={(e) => decodeToken(e.target.value)}
              placeholder="Paste your JWT here (ey...)"
              className="w-full h-64 px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 dark:text-white font-mono text-sm resize-none break-all"
            />
            {error && <p className="text-red-500 text-sm mt-2 font-medium">{error}</p>}
          </div>

          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 shadow-sm flex flex-col">
            <h2 className="font-bold text-lg mb-4 text-zinc-800 dark:text-zinc-200">Decoded Payload</h2>
            <div className="flex-1 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 overflow-y-auto">
              {decoded ? (
                <pre className="font-mono text-sm text-zinc-800 dark:text-zinc-300 whitespace-pre-wrap">
                  <span className="text-pink-500 font-bold">HEADER:</span>{'\n'}
                  {JSON.stringify(decoded.header, null, 2)}
                  {'\n\n'}
                  <span className="text-pink-500 font-bold">PAYLOAD:</span>{'\n'}
                  {JSON.stringify(decoded.payload, null, 2)}
                </pre>
              ) : (
                <p className="text-zinc-400 text-sm text-center mt-10">Paste a valid token to see decoded data</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
