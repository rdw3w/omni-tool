'use client';

import { useState } from 'react';
import { Music, Download, Info } from 'lucide-react';

export default function TiktokDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const [result, setResult] = useState<any>(null);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch('/api/universal-dl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to download media");
      setResult(data);
    } catch (e: any) {
       setResult({ error: e.message || "Failed to download media" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-zinc-50 dark:bg-zinc-950 p-6 md:p-12">
      <div className="max-w-3xl mx-auto w-full mt-12 md:mt-0 relative z-10">
        <header className="mb-10 flex items-center gap-4">
          <div className="w-16 h-16 bg-zinc-200 dark:bg-zinc-800 text-black dark:text-white rounded-2xl flex items-center justify-center shadow-sm">
            <Music size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">TikTok Downloader</h1>
            <p className="text-zinc-500 dark:text-zinc-400 mt-1">Download TikTok videos without watermark.</p>
          </div>
        </header>

        <div className="bg-zinc-200/50 dark:bg-zinc-800/30 border border-zinc-300 dark:border-zinc-700/50 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Info className="text-zinc-700 dark:text-zinc-300 shrink-0 mt-1" size={20} />
          <div className="text-sm text-zinc-800 dark:text-zinc-200">
            <p className="font-bold mb-1">Tool Features & Limitations:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Downloads any public TikTok video completely watermark-free.</li>
              <li>Fully supports TikTok photo galleries and slideshows.</li>
              <li>Region-locked or deleted videos may produce errors. Ensure the link opens in an incognito window.</li>
            </ul>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 shadow-sm">
          <form onSubmit={handleDownload} className="flex flex-col gap-4">
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste TikTok URL here..."
              className="w-full px-4 py-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-500 dark:text-white text-lg"
              required
            />
            <button 
              type="submit"
              disabled={loading || !url}
              className="w-full py-4 bg-black dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 disabled:opacity-50 text-white dark:text-black rounded-xl font-bold transition-colors flex items-center justify-center gap-2"
            >
              {loading ? <Download className="animate-bounce" /> : <Download />}
              {loading ? 'Processing...' : 'Download Video'}
            </button>
          </form>

          {result && (
            <div className="mt-8 border-t border-zinc-200 dark:border-zinc-800 pt-8 flex flex-col items-center">
              {result.error ? (
                 <p className="text-red-500 font-bold">{result.error}</p>
              ) : (
                <div className="w-full flex flex-col items-center gap-6">
                  {result.url && (
                    <video src={result.url} controls className="w-full max-w-sm rounded-xl border border-zinc-200 dark:border-zinc-800" />
                  )}
                  {result.picker && Array.isArray(result.picker) && (
                     <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                       {result.picker.map((item: any, idx: number) => (
                          <div key={idx} className="flex flex-col items-center gap-2">
                            <img src={item.thumb} alt="thumbnail" className="w-full h-24 object-cover rounded-md" />
                            <a href={item.url} target="_blank" rel="noreferrer" className="w-full text-center py-2 bg-black hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 dark:text-black text-white rounded-md text-sm font-bold">DL {idx + 1}</a>
                          </div>
                       ))}
                     </div>
                  )}
                  {result.url && (
                    <a href={result.url} target="_blank" rel="noreferrer" className="w-full max-w-sm py-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-900 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg">
                      <Download size={20} /> Download Media
                    </a>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
